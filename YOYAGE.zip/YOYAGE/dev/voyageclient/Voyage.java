package dev.voyageclient;

import org.lwjgl.opengl.Display;

import dev.voyageclient.event.EventManager;
import dev.voyageclient.event.EventTarget;
import dev.voyageclient.event.impl.ClientTickEvent;
import dev.voyageclient.gui.clickgui.monsoon.MonsoonClickGUI;
import dev.voyageclient.gui.clickgui.newgui.ClickGUI;
import dev.voyageclient.gui.cosmetic.CosmeticGUI;
import dev.voyageclient.gui.glori.GloriGuiTest;
import dev.voyageclient.gui.hud.HUDManager;
import dev.voyageclient.login.UserChecker;
import dev.voyageclient.login.Users;
import dev.voyageclient.mods.ModDraggable;
import dev.voyageclient.mods.ModInstances;
import dev.voyageclient.theme.CurrentTheme;
import dev.voyageclient.theme.Theme;
import dev.voyageclient.util.backend.HWID;
import dev.voyageclient.util.backend.HackDelete;
import dev.voyageclient.util.backend.SessionChanger;
import dev.voyageclient.util.misc.VoyageRPC;
import dev.voyageclient.util.misc.WebhookUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.util.ChatComponentText;

/*
 * Voyage Client is Developed by quickdaffy.
 */
public class Voyage {
	
	/*
	 * Hi crackers!
	 * Wow! You did it! You got
	 * past our shitty obfuscation!
	 * great job! You're so sad that
	 * this is how you spedn your time?
	 * Go get a girlfriend.
	 */
	
	public String NAME = "Voyage";
	public String VERSION = "v1.2";
	public String NAMEVER = NAME + " " + VERSION;
	public static boolean betaVersion = false;
	public static Voyage INSTANCE = new Voyage();
	private VoyageRPC discordRP = new VoyageRPC();
	public HUDManager hudManager;
	public ModInstances modMananager;
	public static Theme currentTheme;
	private static Minecraft mc = Minecraft.getMinecraft();
	public Users users;
	
	public void init() {
		users = new Users();
		users.addUsers();
		
		Display.setTitle(NAMEVER);
		
		discordRP.start();
		modMananager = new ModInstances();
		
		EventManager.register(this);
		
		WebhookUtil.sendMessage(":exclamation:  ALERT! :exclamation: **" + 
		mc.getSession().getUsername() + 
		"** just booted up Voyage **" + VERSION + "!**");
		
		currentTheme = CurrentTheme.getCurrent();
		
		HackDelete.removeCheats();
		
	}
	
	public void start() {
		hudManager = HUDManager.getInstance();
		modMananager.register(hudManager);
	}
	
	public void shutdown() {
		discordRP.shutdown();
	}

	public static void onUpdate() {
		for(ModDraggable m: ModInstances.modules) {
			m.onUpdate();
		}
	}
	
	@EventTarget
	public void onTick(ClientTickEvent e) {
		KeyBinding.setKeyBindState(Minecraft.getMinecraft().gameSettings.keyBindSprint.getKeyCode(), true);
		if(Minecraft.getMinecraft().gameSettings.CLIENT_GUI_MOD_POS.isPressed()) {
			hudManager.openConfigScreen();
			sendMessage("Entered the HUD Position screen.");
		}
		if(Minecraft.getMinecraft().gameSettings.CLICK_GUI.isPressed()) {
			//MonsoonClickGUI.instance.enterGUI();
			mc.displayGuiScreen(new ClickGUI());
			sendMessage("Entered the ClickGUI.");
		}
		if(Minecraft.getMinecraft().gameSettings.MONSOON.isPressed()) {
			MonsoonClickGUI.instance.enterGUI();
		}
		if(Minecraft.getMinecraft().gameSettings.COSMETIC.isPressed()) {
			//mc.displayGuiScreen(new CosmeticGUI());
			GloriGuiTest.INSTANCE.activate();
		}
		
	}
	
	public static final Voyage getInstance() {
		return INSTANCE;
	}
	
	public static void sendMessage(String message) {
        StringBuilder messageBuilder = new StringBuilder();
        messageBuilder.append("&r[&9Voyage&r]").append("&r ");
        messageBuilder.append(message);
        Minecraft.getMinecraft().thePlayer.addChatMessage(new ChatComponentText(messageBuilder.toString().replace("&", "�")));
    }

	public Users getUsers() {
		return users;
	}

	public void setUsers(Users users) {
		this.users = users;
	}
}
