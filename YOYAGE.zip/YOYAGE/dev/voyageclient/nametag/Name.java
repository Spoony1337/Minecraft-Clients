package dev.voyageclient.nametag;

import dev.voyageclient.event.impl.ClientTickEvent;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;

public class Name {
	
	private Minecraft mc = Minecraft.getMinecraft();
	
	@SuppressWarnings("unlikely-arg-type")
	private void onUpdate(ClientTickEvent e) {
		for(EntityPlayer o : mc.theWorld.playerEntities) {
			if(o.getName().equals("quickProgram")) {
				o.setAlwaysRenderNameTag(true);
			}
		}

	}

}
