package dev.voyageclient.theme.themes;

import java.awt.Color;

import dev.voyageclient.theme.Theme;
import net.minecraft.util.ResourceLocation;

public class NormalTheme extends Theme {

	public NormalTheme() {
		super("Normal", 0.1, new ResourceLocation("Voyage/background/voyagebg.png"), new Color(0, 255, 255, 255).getRGB(), -1);
	}

}
