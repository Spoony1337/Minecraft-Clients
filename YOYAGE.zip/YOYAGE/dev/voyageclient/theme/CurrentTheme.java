package dev.voyageclient.theme;

import dev.voyageclient.theme.themes.*;

public class CurrentTheme {
	
	public static Theme current = new RainbowTheme();
	
	public CurrentTheme() {
	}

	public static Theme getCurrent() {
		return current;
	}

	public void setCurrent(Theme current) {
		this.current = current;
	}

}
