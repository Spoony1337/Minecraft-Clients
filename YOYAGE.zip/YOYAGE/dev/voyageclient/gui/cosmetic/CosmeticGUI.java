package dev.voyageclient.gui.cosmetic;

import java.awt.Color;
import java.io.IOException;
import java.util.ArrayList;

import dev.voyageclient.cosmetic.Cosmetic;
import dev.voyageclient.cosmetic.impl.*;
import dev.voyageclient.gui.cosmetic.component.CosmeticComponent;
import dev.voyageclient.mods.ModDraggable;
import dev.voyageclient.util.render.ColorMode;
import dev.voyageclient.util.render.ColorUtil;
import dev.voyageclient.util.render.DrawUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiMultiplayer;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiSelectWorld;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;

public class CosmeticGUI extends GuiScreen {
	
	Minecraft mc = Minecraft.getMinecraft();
	
	FontRenderer font = mc.fontRendererObj;
	ArrayList<CosmeticComponent> cosButtons = new ArrayList<CosmeticComponent>();
	
	@Override
	public boolean doesGuiPauseGame() {
		return false;
	}
	
	@Override
	public void drawScreen(int mouseX, int mouseY, float partialTicks) {
		this.drawDefaultBackground();
		DrawUtil.drawRoundedRect(50, 50, 900, 475, 10, new Color(0, 0, 0, 150).getRGB());
		
		DrawUtil.drawRoundedRect(50, 20, 205, 50, 10, ColorMode.getBgColor()); // 0, 0, 0, 150
		DrawUtil.setColor(-1);
		font.drawString("Cosmetics", 60, 25, new Color(255, 255, 255, 255).getRGB());
		GlStateManager.pushMatrix();
		GlStateManager.scale(0.8, 0.8, 0.8);
		font.drawString("Capes, hats, and other cosmetics.", 75, 45, -1);
		GlStateManager.popMatrix();
		Gui.drawRect(60, 35, 130, 34, -1);
		
		
		if(BetaCape.ownsCosmetic()) {cosButtons.add(new CosmeticComponent(mouseX, mouseY, 75, 75, new BetaCape(null), 1));}
		if(QuickCape.ownsCosmetic()) {cosButtons.add(new CosmeticComponent(mouseX, mouseY, 200, 75, new QuickCape(null), 1));}
		if(RepCape.ownsCosmetic()) {cosButtons.add(new CosmeticComponent(mouseX, mouseY, 325, 75, new RepCape(null), 1));}
		if(NitroCape.ownsCosmetic()) {cosButtons.add(new CosmeticComponent(mouseX, mouseY, 450, 75, new NitroCape(null), 1));}
		if(ozhayCape.ownsCosmetic()) {cosButtons.add(new CosmeticComponent(mouseX, mouseY, 575, 75, new ozhayCape(null), 1));}
	}
	@Override
	public void mouseClicked(int mouseX, int mouseY, int button) {
		for(CosmeticComponent cos : cosButtons) {
			cos.onClick(mouseX, mouseY);
		}
	}
}
