package dev.voyageclient.gui.glori;

import java.awt.Color;

import dev.voyageclient.mods.ModInstances;
import glori.tech.glorigui.GloriGUI;
import glori.tech.glorigui.Panel;
import glori.tech.glorigui.comp.ToggleButton;
import net.minecraft.client.gui.FontRenderer;

public class GloriGuiTest extends GloriGUI {
	
	public static GloriGuiTest INSTANCE = new GloriGuiTest();
	Panel panel;
	
	public GloriGuiTest() {
		panel = new Panel(200, 50, 700, 400, new Color(0, 0, 0, 170).getRGB(), this);
		panels.add(panel);
		
		panel.addButton(new ToggleButton("Test", 210, 60, 240, 100, ModInstances.blockOverlay, panel));
	}
	
}
