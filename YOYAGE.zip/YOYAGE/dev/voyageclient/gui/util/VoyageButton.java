package dev.voyageclient.gui.util;

import java.awt.Color;

import org.lwjgl.input.Mouse;

import com.google.common.primitives.Primitives;

import net.minecraft.client.gui.Gui;

public class VoyageButton {
	
	public boolean pressed;
	public boolean hovered;
	public int width;
	public int height;
	public int y;
	public int x;
	
	public VoyageButton(int mouseX, int mouseY, int x, int y, int width, int height, int color) {
		this.x = x;
		this.y = y;
		this.height = height;
		this.width = width;
		
		this.pressed = (Mouse.getEventButton() == 0) && (this.hovered == true) && (Mouse.getEventButtonState() == true);
		this.hovered = (mouseX > this.x) && (mouseX < this.width) && (mouseY > this.y) && (mouseY < this.height);
		Gui.drawRect(this.x, this.y, this.width, this.height, color);
	}

}
