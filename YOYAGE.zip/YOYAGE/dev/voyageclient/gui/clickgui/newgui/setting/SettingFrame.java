package dev.voyageclient.gui.clickgui.newgui.setting;

import java.awt.Color;
import java.util.ArrayList;


import dev.voyageclient.mods.Category;
import dev.voyageclient.mods.ModDraggable;
import dev.voyageclient.mods.ModInstances;
import dev.voyageclient.mods.Side;
import dev.voyageclient.settings.BooleanSetting;
import dev.voyageclient.settings.ModeSetting;
import dev.voyageclient.settings.Setting;
import dev.voyageclient.util.font.VoyageFontFromAsset;
import dev.voyageclient.util.render.ColorUtil;
import dev.voyageclient.util.render.DrawUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.util.ResourceLocation;

public class SettingFrame extends GuiScreen {
	
	int x, y, width, height;
	int mouseX, mouseY;
	
	Minecraft mc = Minecraft.getMinecraft();
	public static VoyageFontFromAsset font = new VoyageFontFromAsset(new ResourceLocation("Voyage/font/AntipastoPro-DemiBold_trial.ttf"), 23.0F);
	
	public SettingFrame(ModDraggable mod, int x, int y) {
		this.x = x;
		this.y = y;
		this.width = 395;
		this.height = 300;
	}
		
	
	public void render(int mouseX, int mouseY) {
		//DrawUtil.drawRoundedRect(x, y, x + width, y + height, 10, new Color(0, 0, 0, 75).getRGB());
	}
}