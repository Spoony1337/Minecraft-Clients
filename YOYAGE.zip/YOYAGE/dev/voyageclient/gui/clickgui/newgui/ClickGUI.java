package dev.voyageclient.gui.clickgui.newgui;

import java.awt.Color;
import java.io.IOException;
import java.util.ArrayList;

import org.lwjgl.opengl.GL11;

import dev.voyageclient.Voyage;
import dev.voyageclient.cosmetic.Cosmetic;
import dev.voyageclient.gui.clickgui.monsoon.MonsoonClickGUI;
import dev.voyageclient.gui.clickgui.newgui.component.ModComponent;
import dev.voyageclient.gui.mainmenu.components.MainMenuButton;
import dev.voyageclient.gui.mainmenu.components.SmallButton;
import dev.voyageclient.mods.ModDraggable;
import dev.voyageclient.mods.ModInstances;
import dev.voyageclient.mods.Side;
import dev.voyageclient.mods.impl.*;
import dev.voyageclient.util.render.ColorMode;
import dev.voyageclient.util.render.ColorUtil;
import dev.voyageclient.util.render.DrawUtil;
import dev.voyageclient.util.render.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiMultiplayer;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiSelectWorld;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;

public class ClickGUI extends GuiScreen {
	
	Minecraft mc = Minecraft.getMinecraft();
	
	FontRenderer font = mc.fontRendererObj;
	ModComponent modButton = new ModComponent();
	ModDraggable mod;
	ArrayList<ModComponent> modbuttons = new ArrayList<ModComponent>();
	ScaledResolution sr = new ScaledResolution(mc);

	@Override
	public boolean doesGuiPauseGame() {
		return false;
	}
	

  	@Override
    public void initGui() {
  		super.initGui();
        Minecraft.getMinecraft().entityRenderer.loadShader(new ResourceLocation("shaders/post/blur.json"));
        
    }

	@Override
	public void drawScreen(int mouseX, int mouseY, float partialTicks) {
		
		Minecraft.getMinecraft().entityRenderer.loadShader(new ResourceLocation("shaders/post/blur.json"));
		
		DrawUtil.drawRoundedRect(50, 50, sr.getScaledWidth() - 50, sr.getScaledHeight() - 50, 10, ColorMode.getBgColor()); // 0, 0, 0, 150
		
		
		DrawUtil.drawRoundedRect(50, 20, 205, 50, 10, ColorMode.getBgColor()); // 0, 0, 0, 150
		DrawUtil.setColor(-1);
		font.drawString("ClickGUI", 60, 25, new Color(255, 255, 255, 255).getRGB());
		GlStateManager.pushMatrix();
		GlStateManager.scale(0.8, 0.8, 0.8);
		font.drawString("Mods, HUD Components, and others.", 75, 45, -1);
		GlStateManager.popMatrix();
		Gui.drawRect(60, 35, 130, 34, -1);
		
		
		int offsetY = 1;
		int offsetX = 2;
		
		int offsetY2 = 1;
		int offsetX2 = 2;
		
		int offsetY3 = 1;
		int offsetX3 = 2;
		
		int offsetY4 = 1;
		int offsetX4 = 2;
		
		int offsetY5 = 1;
		int offsetX5 = 2;
		
		int countY = 1;
		for(ModDraggable mod : Voyage.INSTANCE.modMananager.modules) {
			if(mc.gameSettings.guiScale == 2) {
				if(mod.getSide() == 1) {
					modbuttons.add(new ModComponent(mod, mouseX, mouseY, 75, 75 * countY + 10, this));
					countY += 1;
				}
				if(mod.getSide() == 2) {
					modbuttons.add(new ModComponent(mod, mouseX, mouseY, 175, 75 * offsetY + 10, this));
					offsetY += 1;
					mod.drawn = true;
				}
				if(mod.getSide() == 3) {
					modbuttons.add(new ModComponent(mod, mouseX, mouseY, 275, 75 * offsetY2 + 10, this));
					offsetY2 += 1;
					mod.drawn = true;
				}
				if(mod.getSide() == 4) {
					modbuttons.add(new ModComponent(mod, mouseX, mouseY, 375, 75 * offsetY3 + 10, this));
					offsetY3 += 1;
					mod.drawn = true;
				}
				if(mod.getSide() == 5) {
					modbuttons.add(new ModComponent(mod, mouseX, mouseY, 475, 75 * offsetY5 + 10, this));
					offsetY5 += 1;
					mod.drawn = true;
				}
			}
			if(mc.gameSettings.guiScale == 3) {
				if(mod.getSide() == 1) {
					modbuttons.add(new ModComponent(mod, mouseX, mouseY, 75, 45 * countY + 10, this));
					countY += 1;
				}
				if(mod.getSide() == 2) {
					modbuttons.add(new ModComponent(mod, mouseX, mouseY, 175, 45 * offsetY + 10, this));
					offsetY += 1;
					mod.drawn = true;
				}
				if(mod.getSide() == 3) {
					modbuttons.add(new ModComponent(mod, mouseX, mouseY, 275, 45 * offsetY2 + 10, this));
					offsetY2 += 1;
					mod.drawn = true;
				}
				if(mod.getSide() == 4) {
					modbuttons.add(new ModComponent(mod, mouseX, mouseY, 375, 45 * offsetY3 + 10, this));
					offsetY3 += 1;
					mod.drawn = true;
				}
				if(mod.getSide() == 5) {
					modbuttons.add(new ModComponent(mod, mouseX, mouseY, 475, 45 * offsetY5 + 10, this));
					offsetY5 += 1;
					mod.drawn = true;
				}
			}
			
			/*if (!openingAnimation.isDone()) {
	            GL11.glEnable(GL11.GL_SCISSOR_TEST);
	            RenderUtil.scissor(width / 2d - (openingAnimation.getOutput() * width / 2d), height / 2d - (openingAnimation.getOutput() * height / 2d), (openingAnimation.getOutput() * width), (openingAnimation.getOutput() * width));
	        }*/
		}
		
		for(ModComponent modButton : modbuttons) {
			modButton.draw(mouseX, mouseY);
		}
		
		//buttonList.add(new SmallButton(69, sr.getScaledWidth() - 70, sr.getScaledHeight() - 30, "Color Mode"));
		
		super.drawScreen(mouseX, mouseY, partialTicks);
	}
	
	@Override
	protected void actionPerformed(GuiButton button) throws IOException {
	
	}
	
	@Override
	public void mouseClicked(int mouseX, int mouseY, int button) throws IOException{
		for(ModComponent modButton : modbuttons) {
			modButton.onClick(mouseX, mouseY, button);
		}
	}
	
	public void drawPlayerHead(int x, int y, int width) {
	      GlStateManager.pushMatrix();
	      float scale = width / 32;
	      GlStateManager.scale(scale, scale, scale);
	      Minecraft.getMinecraft().getTextureManager().bindTexture(Minecraft.getMinecraft().thePlayer.getLocationSkin());
	      GL11.glEnable(GL11.GL_BLEND);
	      this.drawTexturedModalRect(x / scale, y / scale, 32, 32, 32, 32);
	      GL11.glDisable(GL11.GL_BLEND);
	      GlStateManager.popMatrix();
  }

  @Override
    public void onGuiClosed() {
        //Disable Minecrafts blur shader
        Minecraft.getMinecraft().entityRenderer.loadEntityShader(null);
        super.onGuiClosed();
    }
}
