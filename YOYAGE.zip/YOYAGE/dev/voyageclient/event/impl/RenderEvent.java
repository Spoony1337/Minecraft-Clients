package dev.voyageclient.event.impl;

import dev.voyageclient.event.Event;

public class RenderEvent extends Event {

}
