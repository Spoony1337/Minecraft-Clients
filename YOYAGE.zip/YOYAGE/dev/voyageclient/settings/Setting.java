package dev.voyageclient.settings;

public class Setting {

	public String name;
	public boolean focused;
	
}
