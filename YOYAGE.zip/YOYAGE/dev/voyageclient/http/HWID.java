package dev.voyageclient.http;
public class HWID {

	public static String get() {
		return "fake-hwid"; //implemenmt me bitch
	}
	
}
