package dev.voyageclient.http;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import com.google.gson.Gson;

import dev.voyageclient.http.gsonobjects.ObjGlobalSettings;
import dev.voyageclient.http.gsonobjects.ObjIsBanned;
import dev.voyageclient.http.gsonobjects.ObjIsWhitelisted;
import dev.voyageclient.http.gsonobjects.ObjUserCosmetics;
import net.minecraft.client.Minecraft;

public class HTTPFunctions {

	private static final Gson gson = new Gson();
	
	public static void sendHWIDMap() {
		Minecraft mc = Minecraft.getMinecraft();
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair("uuid", mc.getSession().getProfile().getId().toString()));
		params.add(new BasicNameValuePair("username", mc.getSession().getProfile().getName()));
		params.add(new BasicNameValuePair("hwid", HWID.get()));
		HTTPUtils.sendPostAsync(HTTPEndpoints.MAP_UUID, params);
	}
	
	public static boolean isApiUp() {
		HTTPReply reply = HTTPUtils.sendGet(HTTPEndpoints.BASE);
		return reply.getStatusCode() == 200;
	}
	
	public static boolean isBanned() {
		
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair("hwid", HWID.get()));
		HTTPReply reply = HTTPUtils.sendGet(HTTPEndpoints.IS_BANNED, params);
		if(reply.getStatusCode() == 200) {
			ObjIsBanned obj = gson.fromJson(reply.getBody(), ObjIsBanned.class);
			return obj.isBanned();
		}
		return false;
		
	}
	public static boolean isWhitelisted() {
		
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair("hwid", HWID.get()));
		HTTPReply reply = HTTPUtils.sendGet(HTTPEndpoints.IS_WHITELISTED, params);
		if(reply.getStatusCode() == 200) {
			ObjIsWhitelisted obj = gson.fromJson(reply.getBody(), ObjIsWhitelisted.class);
			return obj.isWhitelisted();
		}
		return false;
		
	}
	
	public static ObjUserCosmetics[] downloadUserCosmetics() {
		return gson.fromJson(HTTPUtils.sendGet(HTTPEndpoints.COSMETICS).getBody(), ObjUserCosmetics[].class);
	}
	
	public static ObjGlobalSettings downloadGlobalSettings() {
		return gson.fromJson(HTTPUtils.sendGet(HTTPEndpoints.GLOBAL_SETTINGS).getBody(), ObjGlobalSettings.class);
	}
	
}
