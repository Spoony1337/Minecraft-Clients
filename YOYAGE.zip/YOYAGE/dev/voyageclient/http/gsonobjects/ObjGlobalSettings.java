package dev.voyageclient.http.gsonobjects;

public class ObjGlobalSettings {
	
	private boolean isWhitelisted;
	private String latestVersion;
	
	public boolean isWhitelisted() {
		return isWhitelisted;
	}
	public String getLatestVersion() {
		return latestVersion;
	}

}
