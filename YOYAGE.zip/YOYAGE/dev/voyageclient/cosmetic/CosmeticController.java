package dev.voyageclient.cosmetic;

import java.lang.reflect.Array;
import java.util.ArrayList;

import dev.voyageclient.cosmetic.impl.TopHat;
import dev.voyageclient.cosmetic.impl.BetaCape;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;

public class CosmeticController {
	
	public Minecraft mc = Minecraft.getMinecraft();
	
	
	
	public static boolean shouldRenderBetaCape(AbstractClientPlayer player) {
		//if(CosmeticManager.betaCape.isWearing() && CosmeticManager.betaCape.ownsCosmetic()) {
			return true;
		/*} else {
			return false;
		}*/
	}
	public static boolean shouldRenderQuickCape(AbstractClientPlayer player) {
		/*if(CosmeticManager.quickCape.isWearing() && CosmeticManager.quickCape.ownsCosmetic()) {
			return true;
		} else {*/
			return false;
		//}
	}
	public static boolean shouldRenderRepCape(AbstractClientPlayer player) {
		/*if(CosmeticManager.repCape.isWearing() && CosmeticManager.repCape.ownsCosmetic()) {
			return true;
		} else {*/
			return false;
		//}
	}
	public static boolean shouldRenderNitroCape(AbstractClientPlayer player) {
		/*if(CosmeticManager.nitroCape.isWearing() && CosmeticManager.nitroCape.ownsCosmetic()) {
			return true;
		} else {**/
			return false;
		//}
	}
	public static boolean shouldRenderOzCape(AbstractClientPlayer player) {
		/*if(CosmeticManager.ozhayCape.isWearing() && CosmeticManager.nitroCape.ownsCosmetic()) {
			return true;
		} else {*/
			return false;
		//}
	}
	public static boolean shouldRenderWings(AbstractClientPlayer player) {
		return false;
	}
	/*public static boolean shouldRenderTopHat(AbstractClientPlayer player) {
		if(TopHat.isWearing() && TopHat.owns) {
			return true;
		} else {
			return false;
		}
	}*/
	public static boolean shouldRenderHalo(AbstractClientPlayer player){
		return false;
	}
	public static float[] getTopHatColor(AbstractClientPlayer player) {
		return new float[] {1, 0, 1};
	}
}
