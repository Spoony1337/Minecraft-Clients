package dev.voyageclient.util.backend;

import java.security.MessageDigest;

public class HWID {
	
	public static String HWID;

	public static String getHWID() {
        try{
            String toEncrypt =  System.getenv("COMPUTERNAME") + System.getProperty("user.name") + System.getenv("PROCESSOR_IDENTIFIER") + System.getenv("PROCESSOR_LEVEL");
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(toEncrypt.getBytes());
            StringBuffer hexString = new StringBuffer();
            
            byte byteData[] = md.digest();
            
            for (byte aByteData : byteData) {
                String hex = Integer.toHexString(0xff & aByteData);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            
            HWID = hexString.toString();
            System.out.println(HWID);
            
            return hexString.toString();
            
        } catch (Exception e) {
            e.printStackTrace(); 
            System.out.println("error");
        	return "Error";
        }
    }
}