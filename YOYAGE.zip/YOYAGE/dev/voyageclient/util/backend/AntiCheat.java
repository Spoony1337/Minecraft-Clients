package dev.voyageclient.util.backend;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Vector;

public class AntiCheat {

	/*public static boolean checkVape() {
        try {
            final ClassLoader classLoader = ClassLoader.getSystemClassLoader();
            final Field classesField = ClassLoader.class.getDeclaredField("classes");
            classesField.setAccessible(true);
            final Vector<Class<?>> classes = (Vector<Class<?>>) classesField.get(classLoader);
            for (Class<?> classFor : classes) {
                if (classFor.getName().equalsIgnoreCase("a.A")) {
                    for (Method method : classFor.getMethods()) {
                        if (method.getName().equals("test") && method.getParameterCount() == 0) {
                            return true;
                        }
                    }
                }
            }
        } catch (Exception e) {
        	System.out.println("Failedthe check for Vape v4");
            e.printStackTrace();
        }
        return false;
    }
	
	public static void doAnticheat() {
		checkVape();
	}*/
	
}
