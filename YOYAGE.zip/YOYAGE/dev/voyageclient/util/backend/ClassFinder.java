package dev.voyageclient.util.backend;

import java.util.Set;

import org.reflections.Reflections;
import org.reflections.ReflectionsException;

public class ClassFinder {

    public static Set<Class> findClasses(String pack, Class subType) {
        Reflections reflections = new Reflections(pack);
        return reflections.getSubTypesOf(subType);
    }
}