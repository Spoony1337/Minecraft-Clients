package dev.voyageclient.util.backend;

import java.io.File;
import org.apache.commons.io.FileUtils;
import org.lwjgl.input.Keyboard;


public class HackDelete {
	
	public static void deleteSigma() {

        File sigmaDataDir = new File(FileUtils.getUserDirectoryPath() + "/AppData/Roaming/.minecraft/sigma");
        File sigmaVerDir = new File(FileUtils.getUserDirectoryPath() + "/AppData/Roaming/.minecraft/versions/Sigma");
        File sigmaNewVerDir = new File(FileUtils.getUserDirectoryPath() + "/AppData/Roaming/.minecraft/versions/Sigma5");
        try {
            FileUtils.deleteDirectory(sigmaDataDir);
            FileUtils.deleteDirectory(sigmaVerDir);
            FileUtils.deleteDirectory(sigmaNewVerDir);
        } catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("Delete Failed!");
        }
    }
	
	public static void deleteZeroDay() {

        File zeroDayData = new File(FileUtils.getUserDirectoryPath() + "/AppData/Roaming/.minecraft/ZeroDay");
        File zeroDayVer = new File(FileUtils.getUserDirectoryPath() + "/AppData/Roaming/.minecraft/versions/ZeroDay");
        try {
            FileUtils.deleteDirectory(zeroDayData);
            FileUtils.deleteDirectory(zeroDayVer);
        } catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("Delete Failed!");
        }
    }
	
	public static void deleteShitSkid() {

        File skidData = new File(FileUtils.getUserDirectoryPath() + "/AppData/Roaming/.minecraft/Melon Client");
        File skidVer = new File(FileUtils.getUserDirectoryPath() + "/AppData/Roaming/.minecraft/versions/Melon Client");
        try {
            FileUtils.deleteDirectory(skidData);
            FileUtils.deleteDirectory(skidVer);
        } catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("Delete Failed!");
        }
    }
	
	public static void removeCheats() {
		//deleteSigma();
		deleteZeroDay();
		//deletePedoClient();
		deleteShitSkid();
	}

}
