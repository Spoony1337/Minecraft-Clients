package dev.voyageclient.mods.impl;

import dev.voyageclient.event.impl.ClientTickEvent;
import dev.voyageclient.gui.hud.ScreenPosition;
import dev.voyageclient.mods.Category;
import dev.voyageclient.mods.ModDraggable;
import dev.voyageclient.mods.Side;
import dev.voyageclient.settings.ModeSetting;
import net.minecraft.client.Minecraft;

public class SwordAnimations extends ModDraggable {
	
	//public ModeSetting mode = new ModeSetting("Mode", "Spin", "Spin");
	
	public SwordAnimations() {
		super("Sword Animations", "Cool sword animations", Category.WORLD, 4);
		//this.addSettings(mode);
	}
	
	private ScreenPosition pos;

	@Override
	public int getWidth() {
		return 0;
	}

	@Override
	public int getHeight() {
		return 0;
	}

	@Override
	public void render(ScreenPosition pos) {
		
	}

}