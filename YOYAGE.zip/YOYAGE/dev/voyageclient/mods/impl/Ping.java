package dev.voyageclient.mods.impl;

import dev.voyageclient.gui.hud.ScreenPosition;
import dev.voyageclient.mods.Category;
import dev.voyageclient.mods.ModDraggable;
import dev.voyageclient.mods.Side;

public class Ping extends ModDraggable {
	
	public Ping() {
		super("Ping Display", "Displays your ping.", Category.HUD, 2);
	}

	private ScreenPosition pos;
		
	@Override
	public int getWidth() {
		return 35;
	}

	@Override
	public int getHeight() {
		
		return 10;
		
	}

	@Override
	public void render(ScreenPosition pos) {
		int ping = mc.getMinecraft().getNetHandler().getPlayerInfo(mc.getMinecraft().thePlayer.getUniqueID()).getResponseTime();
		if(ping <= 10) {
			font.drawStringWithShadow("�b  " + ping + " ms", pos.getAbsoluteX(), pos.getAbsoluteY(), -1);
			return;
		} else if (ping <= 50) {
			font.drawStringWithShadow("�a  " + ping + " ms", pos.getAbsoluteX(), pos.getAbsoluteY(), -1);
			return;
		} else if (ping <= 100) {
			font.drawStringWithShadow("�2  " + ping + " ms", pos.getAbsoluteX(), pos.getAbsoluteY(), -1);
			return;
		} else if (ping <= 150) {
			font.drawStringWithShadow("�e  " + ping + " ms" , pos.getAbsoluteX(), pos.getAbsoluteY(), -1);
			return;
		} else if (ping <= 180) {
			font.drawStringWithShadow("�c  " + ping + " ms", pos.getAbsoluteX(), pos.getAbsoluteY(), -1);
			return;
		} else {
			font.drawStringWithShadow("�4  " + ping + " ms", pos.getAbsoluteX(), pos.getAbsoluteY(), -1);
			return;
		}
		
	}
	

}