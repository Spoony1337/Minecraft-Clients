package dev.voyageclient.mods.impl;

import dev.voyageclient.event.EventTarget;
import dev.voyageclient.event.impl.ClientTickEvent;
import dev.voyageclient.gui.hud.ScreenPosition;
import dev.voyageclient.mods.Category;
import dev.voyageclient.mods.ModDraggable;
import dev.voyageclient.mods.Side;
import net.minecraft.potion.Potion;

public class ToggleSprint extends ModDraggable{
	
	float f = 0.8F;
	
	/*boolean flags = !mc.thePlayer.movementInput.sneak &&
            (mc.thePlayer.getFoodStats().getFoodLevel() > 6.0F || mc.thePlayer.capabilities.allowFlying) &&
            !mc.thePlayer.isPotionActive(Potion.blindness) &&
            mc.thePlayer.movementInput.moveForward >= f &&
            !mc.thePlayer.isSprinting() &&
            !mc.thePlayer.isUsingItem() &&
            !mc.thePlayer.isCollidedHorizontally &&
            sprintingToggled;*/

 
	public ToggleSprint() {
		super("ToggleSprint", "Toggles if you're sprinting or not.", Category.PLAYER, 3);
	}

	@Override
	public int getWidth() {
		return font.getStringWidth("[Sprinting (KeyHeld)]");
	}
 
	@Override
	public int getHeight() {
		return font.FONT_HEIGHT;
	}
	@EventTarget
	public void onTick(ClientTickEvent e) {
		if(isEnabled) {
			if(mc.gameSettings.keyBindForward.isKeyDown() && !mc.thePlayer.isUsingItem() && !mc.thePlayer.isSneaking() && !mc.thePlayer.isCollidedHorizontally &&  (mc.thePlayer.getFoodStats().getFoodLevel() > 6.0F || mc.thePlayer.capabilities.allowFlying) && !mc.thePlayer.isPotionActive(Potion.blindness) &&  mc.thePlayer.movementInput.moveForward >= f &&  !mc.thePlayer.isSprinting() && !mc.thePlayer.capabilities.isFlying && mc.thePlayer.isInLava() && mc.thePlayer.isInWater() && this.isEnabled()) {
	            mc.thePlayer.setSprinting(true);
			}
		}
	}
	@Override
	public void render(ScreenPosition pos) {
		if(!mc.thePlayer.capabilities.isFlying && !mc.thePlayer.isSprinting() && !mc.thePlayer.isRiding() && (mc.thePlayer.movementInput.moveForward > 0.1) && !mc.gameSettings.keyBindBack.isKeyDown() && !mc.gameSettings.keyBindRight.isKeyDown() && !mc.gameSettings.keyBindLeft.isKeyDown() && !mc.thePlayer.isSprinting() && !mc.thePlayer.isRiding()) {
			font.drawString("[Walking (Vanilla)]", pos.getAbsoluteX(), pos.getAbsoluteY(), -1);
		}
 
		if(!mc.thePlayer.capabilities.isFlying && !mc.thePlayer.isSprinting() && !mc.thePlayer.isRiding() && mc.gameSettings.keyBindBack.isKeyDown() && !mc.gameSettings.keyBindRight.isKeyDown() && !mc.gameSettings.keyBindLeft.isKeyDown() && !mc.thePlayer.isSprinting() && !mc.thePlayer.isRiding()) {
			font.drawString("[Walking (Vanilla)]", pos.getAbsoluteX(), pos.getAbsoluteY(), -1);
		}
 
		if(!mc.thePlayer.capabilities.isFlying && mc.gameSettings.keyBindRight.isKeyDown() && !mc.gameSettings.keyBindLeft.isKeyDown() && !mc.thePlayer.isSprinting() && !mc.thePlayer.isRiding()) {
			font.drawString("[Strafing (Vanilla)]", pos.getAbsoluteX(), pos.getAbsoluteY(), -1);
		}
 
		if(!mc.thePlayer.isRiding() && mc.thePlayer.capabilities.isFlying) {
			font.drawString("[Flying (Vanilla)]", pos.getAbsoluteX(), pos.getAbsoluteY(), -1);
		}
 
		if(!mc.thePlayer.capabilities.isFlying && !mc.gameSettings.keyBindRight.isKeyDown() && mc.gameSettings.keyBindLeft.isKeyDown() && !mc.thePlayer.isSprinting() && !mc.thePlayer.isRiding()) {
			font.drawString("[Strafing (Vanilla)]", pos.getAbsoluteX(), pos.getAbsoluteY(), -1);
		}
 
		if(!mc.thePlayer.capabilities.isFlying && mc.thePlayer.isSprinting() && !mc.thePlayer.isRiding()) {
			font.drawString("[Sprinting (Vanilla)]", pos.getAbsoluteX(), pos.getAbsoluteY(), -1);
		}
 
		if(!mc.thePlayer.capabilities.isFlying && !mc.thePlayer.isSprinting() && !mc.thePlayer.isRiding() && !(mc.thePlayer.movementInput.moveForward > 0.1) && !mc.gameSettings.keyBindBack.isKeyDown() && !mc.gameSettings.keyBindRight.isKeyDown() && !mc.gameSettings.keyBindLeft.isKeyDown()) {
			font.drawString("[Standing (NoKeyHeld)]", pos.getAbsoluteX(), pos.getAbsoluteY(), -1);
		}
 
 
	}
 
	@Override
	public void renderDummy(ScreenPosition pos) {
		font.drawString("[Sprinting (Vanilla)]", pos.getAbsoluteX(), pos.getAbsoluteY(), -1);
	}
 
}