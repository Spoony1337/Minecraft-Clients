package dev.voyageclient.mods.impl;

import dev.voyageclient.gui.hud.ScreenPosition;
import dev.voyageclient.mods.Category;
import dev.voyageclient.mods.ModDraggable;
import dev.voyageclient.mods.Side;
import dev.voyageclient.settings.ModeSetting;
import dev.voyageclient.settings.NumberSetting;

public class TimeChanger extends ModDraggable {
	
	//ModeSetting timeMode = new ModeSetting("Time", "Night", "Day", "Night");
	
	public TimeChanger() {
		super("Time Changer", "Changes the time to night.",Category.WORLD, 3);
	}
	
	
	@Override
	public void onUpdate() {
		
	}

	private ScreenPosition pos;

	@Override
	public int getWidth() {
		return 0;
	}

	@Override
	public int getHeight() {
		return 0;
	}

	@Override
	public void render(ScreenPosition pos) {
		
	}

	@Override
	public void save(ScreenPosition pos) {
		this.pos = pos;
		
	}

	@Override
	public ScreenPosition load() {
		return pos;
	}

}