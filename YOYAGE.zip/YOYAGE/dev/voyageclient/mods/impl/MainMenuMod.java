package dev.voyageclient.mods.impl;

import java.text.SimpleDateFormat;
import java.util.Date;

import dev.voyageclient.Voyage;
import dev.voyageclient.gui.hud.ScreenPosition;
import dev.voyageclient.mods.Category;
import dev.voyageclient.mods.ModDraggable;
import dev.voyageclient.mods.Side;
import dev.voyageclient.settings.ModeSetting;
import net.minecraft.client.gui.Gui;
import net.minecraft.util.ResourceLocation;

public class MainMenuMod extends ModDraggable {
	
	public ModeSetting mode = new ModeSetting("Theme", "Voyage", "Voyage", "ZeroTwo");

	public MainMenuMod() {
		super("MainMenu", "Configure the Main menu.", Category.HUD, 5);
		addSettings(mode);
	}
	
	private ScreenPosition pos;
	
	
	
	@Override
	public int getWidth() {
		return 0;
	}
	

	@Override
	public int getHeight() {
		return 0;
	}

	@Override
	public void render(ScreenPosition pos) {
		
	}

	
	
}
