package dev.voyageclient.mods.impl;

import dev.voyageclient.gui.hud.ScreenPosition;
import dev.voyageclient.mods.Category;
import dev.voyageclient.mods.ModDraggable;
import dev.voyageclient.mods.Side;
import net.minecraft.client.gui.Gui;

public class FPS extends ModDraggable {

	public FPS() {
		super("FPS", "Displays your frames per second.", Category.HUD, 1);
		// TODO Auto-generated constructor stub
	}

	private ScreenPosition pos;
	
	
	@Override
	public int getWidth() {
		return font.getStringWidth(mc.getDebugFPS() + " FPS");
	}

	@Override
	public int getHeight() {
		// TODO Auto-generated method stub
		return 10;
	}

	@Override
	public void render(ScreenPosition pos) {
		Gui.drawRect(pos.getAbsoluteX() - 2, pos.getAbsoluteY() - 2, pos.getAbsoluteX() + font.getStringWidth(mc.getDebugFPS() + " FPS") + 2, pos.getAbsoluteY() + getHeight(), 0x90000000);
		font.drawString(mc.getDebugFPS() + " FPS", pos.getAbsoluteX(), pos.getAbsoluteY(), -1);
		
	}

	
	
}
