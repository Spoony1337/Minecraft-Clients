package dev.voyageclient.mods.impl;

import java.util.ArrayList;
import java.util.List;

import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

import dev.voyageclient.gui.hud.ScreenPosition;
import dev.voyageclient.mods.Category;
import dev.voyageclient.mods.ModDraggable;
import dev.voyageclient.mods.Side;
import dev.voyageclient.util.misc.WebhookUtil;
import dev.voyageclient.util.render.DrawUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.GlStateManager;



public class PlayerHead extends ModDraggable {
	
	public PlayerHead() {
		super("PlayerHead", "Shows your player's head.", Category.HUD, 4);
	}
	

	@Override
	public int getWidth() {
		return 31;
	}

	@Override
	public int getHeight() {
		return 31;
	}

	@Override
	public void render(ScreenPosition pos) {
		DrawUtil.setColor(-1);
		DrawUtil.instance.drawPlayerHead(pos.getAbsoluteX(), pos.getAbsoluteY(), 50);
	}
	
}
