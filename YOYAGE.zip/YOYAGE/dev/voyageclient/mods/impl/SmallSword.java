package dev.voyageclient.mods.impl;

import dev.voyageclient.event.impl.ClientTickEvent;
import dev.voyageclient.gui.hud.ScreenPosition;
import dev.voyageclient.mods.Category;
import dev.voyageclient.mods.ModDraggable;
import dev.voyageclient.mods.Side;
import dev.voyageclient.settings.ModeSetting;
import net.minecraft.client.Minecraft;

public class SmallSword extends ModDraggable {
	
	
	public SmallSword() {
		super("ItemViewModel", "Makes your held item smaller.", Category.WORLD, 3);
	}
	
	private ScreenPosition pos;

	@Override
	public int getWidth() {
		return 0;
	}

	@Override
	public int getHeight() {
		return 0;
	}

	@Override
	public void render(ScreenPosition pos) {
		
	}

}