package dev.voyageclient.mods.impl;

import java.text.SimpleDateFormat;
import java.util.Date;

import dev.voyageclient.Voyage;
import dev.voyageclient.gui.hud.ScreenPosition;
import dev.voyageclient.mods.Category;
import dev.voyageclient.mods.ModDraggable;
import dev.voyageclient.mods.Side;
import net.minecraft.client.gui.Gui;
import net.minecraft.util.ResourceLocation;

public class ActiveMods extends ModDraggable {

	public ActiveMods() {
		super("ArrayList", "Commonly seen in Hacked Clients", Category.HUD, 4);
	}
	private ScreenPosition pos;
	
	
	
	@Override
	public int getWidth() {
		return 0;
	}
	

	@Override
	public int getHeight() {
		return 0;
	}

	@Override
	public void render(ScreenPosition pos) {
		
	}

	
	
}
