package dev.voyageclient.mods.impl;

import dev.voyageclient.event.impl.ClientTickEvent;
import dev.voyageclient.gui.hud.ScreenPosition;
import dev.voyageclient.mods.Category;
import dev.voyageclient.mods.ModDraggable;
import dev.voyageclient.mods.Side;
import net.minecraft.client.Minecraft;

public class BlockOverlay extends ModDraggable{
	
	public BlockOverlay() {
		super("Block Overlay", "Renders a cool af overlay over each block.", Category.WORLD, 3);
	}
	
	private ScreenPosition pos;

	@Override
	public int getWidth() {
		return 0;
	}

	@Override
	public int getHeight() {
		return 0;
	}

	@Override
	public void render(ScreenPosition pos) {
		
	}

}