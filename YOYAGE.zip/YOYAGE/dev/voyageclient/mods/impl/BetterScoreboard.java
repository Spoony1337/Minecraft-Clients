package dev.voyageclient.mods.impl;

import dev.voyageclient.event.impl.ClientTickEvent;
import dev.voyageclient.gui.hud.ScreenPosition;
import dev.voyageclient.mods.Category;
import dev.voyageclient.mods.ModDraggable;
import dev.voyageclient.mods.Side;
import net.minecraft.client.Minecraft;

public class BetterScoreboard extends ModDraggable{
	
	public BetterScoreboard() {
		super("BetterScoreboard", "Makes the scoreboard better.", Category.HUD, 4);
	}
	
	public boolean transparent = true;
	public boolean noNumbers = true;
	

	@Override
	public int getWidth() {
		return 0;
	}

	@Override
	public int getHeight() {
		return 0;
	}

	@Override
	public void render(ScreenPosition pos) {
		
	} 

}