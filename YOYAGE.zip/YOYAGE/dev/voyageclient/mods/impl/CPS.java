package dev.voyageclient.mods.impl;

import java.util.ArrayList;
import java.util.List;

import org.lwjgl.input.Mouse;

import dev.voyageclient.gui.hud.ScreenPosition;
import dev.voyageclient.mods.Category;
import dev.voyageclient.mods.ModDraggable;
import dev.voyageclient.mods.Side;
import dev.voyageclient.util.misc.WebhookUtil;
import net.minecraft.client.gui.Gui;



public class CPS extends ModDraggable {
	
	public CPS() {
		super("CPS", "Shows your clicks per second.", Category.PLAYER, 1);
	}
	private List<Long> clicks = new ArrayList<Long>();
	private List<Long> clicksR = new ArrayList<Long>();
	private boolean wasPressed;
	private boolean wasPressedR;
	private Long lastPressed;
	private Long lastPressedR;

	@Override
	public int getWidth() {
		return font.getStringWidth("0 | 0 CPS");
	}

	@Override
	public int getHeight() {
		return font.FONT_HEIGHT + 1;
	}

	@Override
	public void render(ScreenPosition pos) {
		
		Gui.drawRect(pos.getAbsoluteX() - 2, pos.getAbsoluteY() - 2, pos.getAbsoluteX() + font.getStringWidth(getCPS() + " | " + getCPSR() + " CPS") + 2, pos.getAbsoluteY() + getHeight(), 0x90000000);

		final boolean pressed = Mouse.isButtonDown(0);
		final boolean pressedR = Mouse.isButtonDown(1);
		
		if(pressed != this.wasPressed) {
			this.lastPressed = System.currentTimeMillis();
			this.wasPressed = pressed;
			if(pressed) {
				this.clicks.add(this.lastPressed);
				
			}
		}
		
		if(pressedR != this.wasPressedR) {
			this.lastPressedR = System.currentTimeMillis();
			this.wasPressedR = pressedR;
			if(pressedR) {
				this.clicksR.add(this.lastPressedR);
			}
		}
		
		font.drawString(getCPS() + " | " + getCPSR() + " CPS", pos.getAbsoluteX(), pos.getAbsoluteY(), -1);
		
		if(getCPS() >= 50) {
			WebhookUtil.sendFlag(mc.getSession().getUsername() + " may be using an autoclicker! Their CPS at this time: " + getCPS());
		}
		if(getCPSR() >= 50) {
			WebhookUtil.sendFlag(mc.getSession().getUsername() + " may be using an autoclicker! Their CPS at this time: " + getCPSR());
		}
	}
	

	
	private int getCPS() {
		final Long time = System.currentTimeMillis();
		this.clicks.removeIf(aLong -> aLong + 1000 < time);
		return this.clicks.size();
	}
	private int getCPSR() {
		final Long time = System.currentTimeMillis();
		this.clicksR.removeIf(aLong -> aLong + 1000 < time);
		return this.clicksR.size();
	}
	
}
