package dev.voyageclient.mods.impl;

import java.text.SimpleDateFormat;
import java.util.Date;

import dev.voyageclient.gui.hud.ScreenPosition;
import dev.voyageclient.mods.Category;
import dev.voyageclient.mods.ModDraggable;
import dev.voyageclient.mods.Side;
import net.minecraft.client.gui.Gui;

public class Clock extends ModDraggable {

	public Clock() {
		super("Clock", "Displays the current time in your area.", Category.HUD, 4);
	}
	boolean yes = true;
	Date date;
	private ScreenPosition pos;
	
	SimpleDateFormat formatter = new SimpleDateFormat("HH:mm");
	
	
	@Override
	public int getWidth() {
		return font.getStringWidth(formatter.format(date));
	}

	@Override
	public int getHeight() {
		return 10;
	}

	@Override
	public void render(ScreenPosition pos) {
		SimpleDateFormat formatter = new SimpleDateFormat("HH:mm");
		date = new Date(System.currentTimeMillis());
		Gui.drawRect(pos.getAbsoluteX() - 2, pos.getAbsoluteY() - 2, pos.getAbsoluteX() + font.getStringWidth(formatter.format(date)) + 2, pos.getAbsoluteY() + getHeight(), 0x90000000);
		font.drawString(formatter.format(date), pos.getAbsoluteX(), pos.getAbsoluteY(), -1);
		
	}

	
	
}
