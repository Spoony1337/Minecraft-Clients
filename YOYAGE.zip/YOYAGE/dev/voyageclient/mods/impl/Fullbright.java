package dev.voyageclient.mods.impl;

import dev.voyageclient.event.impl.ClientTickEvent;
import dev.voyageclient.gui.hud.ScreenPosition;
import dev.voyageclient.mods.Category;
import dev.voyageclient.mods.ModDraggable;
import dev.voyageclient.mods.Side;
import net.minecraft.client.Minecraft;

public class Fullbright extends ModDraggable{
	
	public Fullbright() {
		super("Fullbright", "Makes the world Brighter. Not allowed on some servers.", Category.PLAYER, 2);
	}
	
	private ScreenPosition pos;

	@Override
	public int getWidth() {
		return 0;
	}

	@Override
	public int getHeight() {
		return 0;
	}

	@Override
	public void render(ScreenPosition pos) {
		
	}

	@Override
	public void save(ScreenPosition pos) {
		this.pos = pos;
		
	}

	@Override
	public ScreenPosition load() {
		return pos;
	}
	
	@Override
	public void onEnable() {
		mc.gameSettings.gammaSetting = 100;
	}
	
	@Override
	public void onDisable() {
		mc.gameSettings.gammaSetting = 1;
	}

}