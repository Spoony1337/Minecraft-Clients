package dev.voyageclient.mods.impl;

import java.text.SimpleDateFormat;
import java.util.Date;

import dev.voyageclient.Voyage;
import dev.voyageclient.gui.clickgui.monsoon.MonsoonClickGUI;
import dev.voyageclient.gui.hud.ScreenPosition;
import dev.voyageclient.gui.clickgui.newgui.ClickGUI;
import dev.voyageclient.mods.Category;
import dev.voyageclient.mods.ModDraggable;
import dev.voyageclient.mods.Side;
import dev.voyageclient.settings.ModeSetting;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.util.ResourceLocation;

public class ClickGuiMod extends ModDraggable {
	
	private static final ClickGUI clickGUI = new ClickGUI();



	//public ModeSetting mode = new ModeSetting("Mode", "Normal", "Normal", "Hacked");

	public ClickGuiMod() {
		super("Monsoon", "Enter Monsoon ClickGUI.", Category.HUD, 6);
		this.isEnabled = false;
	}
	
	private ScreenPosition pos;
	
	
	
	@Override
	public int getWidth() {
		return 0;
	}
	

	@Override
	public int getHeight() {
		return 0;
	}

	@Override
	public void render(ScreenPosition pos) {
		
	}
	
	@Override
	public void onEnable() {
		
	}

	
	
}
