package dev.voyageclient.mods.impl;

import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.Display;

import dev.voyageclient.event.EventTarget;
import dev.voyageclient.event.impl.ClientTickEvent;
import dev.voyageclient.event.impl.KeyEvent;
import dev.voyageclient.gui.hud.ScreenPosition;
import dev.voyageclient.mods.Category;
import dev.voyageclient.mods.ModDraggable;
import dev.voyageclient.mods.Side;
import net.minecraft.client.Minecraft;

public class Freelook extends ModDraggable {
	
	private boolean returnOnRelease = true;
	private boolean freelooking = false;
	
	private float cameraYaw = 0f;
	private float cameraPitch = 0f;
	private int previousF5 = 0;
	
	@EventTarget
	public void onKey(KeyEvent e) {
		
		if(e.getKey() == mc.gameSettings.FREELOOK.getKeyCode() && this.isEnabled) {
				if (Keyboard.getEventKeyState())
				{
					System.out.println("frelloked");
					freelooking = !freelooking;
					cameraYaw = mc.thePlayer.rotationYaw;
					cameraPitch = mc.thePlayer.rotationPitch;

					if (freelooking)
					{
						previousF5 = mc.gameSettings.thirdPersonView;
						mc.gameSettings.thirdPersonView = 1;
					}
					else
					{
						mc.gameSettings.thirdPersonView = previousF5;
					}
				}
				else if (returnOnRelease)
				{
					freelooking = false;
					mc.gameSettings.thirdPersonView = previousF5;
				}
			}

			if (Keyboard.getEventKey() == mc.gameSettings.keyBindTogglePerspective.getKeyCode())
			{
				freelooking = false;
			}
		
	}

	public float getCameraYaw()
	{
		return freelooking ? cameraYaw : mc.thePlayer.rotationYaw;
	}

	public float getCameraPitch()
	{
		return freelooking ? cameraPitch : mc.thePlayer.rotationPitch;
	}

	public boolean overrideMouse()
	{
		if (mc.inGameHasFocus && Display.isActive())
		{
			if (!freelooking)
			{
				return true;
			}

			// CODE
			mc.mouseHelper.mouseXYChange();
			float f1 = mc.gameSettings.mouseSensitivity * 0.6F + 0.2F;
			float f2 = f1 * f1 * f1 * 8.0F;
			float f3 = (float) mc.mouseHelper.deltaX * f2;
			float f4 = (float) mc.mouseHelper.deltaY * f2;

			cameraYaw += f3 * 0.15F;
			cameraPitch += f4 * 0.15F;

			if (cameraPitch > 90) cameraPitch = 90;
			if (cameraPitch < -90) cameraPitch = -90;
		}

		return false;
	}
	public Freelook() {
		super("Freelook", "Look all around your player!", Category.PLAYER, 1);
	}

	@Override
	public int getWidth() {
		return font.getStringWidth("[Freelooking]");
	}

	@Override
	public int getHeight() {
		return font.FONT_HEIGHT;
	}

	@Override
	public void render(ScreenPosition pos) {
		if(freelooking) {
			font.drawString("[Freelooking]", pos.getAbsoluteX(), pos.getAbsoluteY(), -1);
			System.out.println(freelooking);
		}
	}
	
	@Override
	public void renderDummy(ScreenPosition pos) {
		font.drawString("[Freelooking]", pos.getAbsoluteX(), pos.getAbsoluteY(), -1);
	}

}
