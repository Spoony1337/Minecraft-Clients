package dev.voyageclient.mods.impl;

import java.awt.Color;

import dev.voyageclient.gui.hud.ScreenPosition;
import dev.voyageclient.mods.Category;
import dev.voyageclient.mods.ModDraggable;
import dev.voyageclient.util.render.DrawUtil;

public class Notifications extends ModDraggable {

	public Notifications() {
		super("Notifications", "Displays helpful info when you need it.", Category.HUD, 3);
	}
	
	public String name;
	public String text;
	public int length;
	public boolean isRunning = false;

	@Override
	public int getWidth() {
		return 120;
	}

	@Override
	public int getHeight() {
		return 50;
	}

	@Override
	public void render(ScreenPosition pos) {
		if(isRunning) {
			DrawUtil.drawRoundedRect(pos.getAbsoluteX(), pos.getAbsoluteY(), pos.getAbsoluteX() + getWidth(), pos.getAbsoluteY() + getHeight(), 10, new Color(0, 0, 0, 255).getRGB());
			mc.fontRendererObj.drawString(name, pos.getAbsoluteX() + 3, pos.getAbsoluteY() - 6, -1);
			mc.fontRendererObj.drawString(text, pos.getAbsoluteX() + 3, pos.getAbsoluteY() - 12, -1);
		}
	}
	
	public void sendNotif(String name, String text, int length) {
		this.name = name;
		this.text = text;
		this.length = length;
		while (System.currentTimeMillis() < length * 1000) {
			isRunning = true;
		}
	}

}
