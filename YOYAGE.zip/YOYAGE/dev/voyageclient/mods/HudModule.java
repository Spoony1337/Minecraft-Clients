package dev.voyageclient.mods;

import com.lukflug.panelstudio.settings.Toggleable;

import dev.voyageclient.Voyage;
import dev.voyageclient.event.EventManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;

public class HudModule implements Toggleable {
	
	private boolean isEnabled = true;
	
	protected final Minecraft mc;
	protected final FontRenderer font;
	protected final Voyage client;
	
	public HudModule() {
		this.mc = Minecraft.getMinecraft();
		this.font = this.mc.fontRendererObj;
		this.client = Voyage.getInstance();
		
		setEnabled(isEnabled);
	}

	public void setEnabled(boolean isEnabled) {
		this.isEnabled = isEnabled;
		if(isEnabled) {
			EventManager.register(this);
		}
		else {
			EventManager.unregister(this);
		}
		
	}
	
	public void toggle() {
		setEnabled(!isEnabled);
	}
	
	public void onEnable() {
		
	}
	
	public void onDisable() {
		
	}
	public boolean isEnabled() {
		return isEnabled;
	}

	@Override
	public boolean isOn() {
		return isEnabled;
	}

}
