package dev.voyageclient.mods;

public enum Side {
	
	LEFT,
	RIGHT;

}
