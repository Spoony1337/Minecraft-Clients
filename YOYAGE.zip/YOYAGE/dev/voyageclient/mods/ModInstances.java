package dev.voyageclient.mods;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Collectors;

import dev.voyageclient.gui.hud.HUDManager;
import dev.voyageclient.mods.impl.*;
import dev.voyageclient.util.backend.ClassFinder;

public class ModInstances {
	
	public static ArrayList<ModDraggable> modules;

	
	private static ArmorStatus armorStatus;
	private static FPS FPS;
	private static CPS CPS;
	private static Keystrokes keystrokes;
	private static Coordinates coords;
	private static TargetHud targetHud;
	public static Freelook freelook;
	private static TimeChanger timeChanger;
	private static Fullbright fullbright;
	private static Ping ping;
	private static PotionStatus potionStatus;
	private static ToggleSprint toggleSprint;
	public static SmallSword smallSword;
	public static BlockOverlay blockOverlay;
	public static Notifications notifications;
	public static Clock clock;
	public static BetterScoreboard betterScoreboard;
	public static SwordAnimations swordAnimations;
	public static Watermark watermark;
	public static ActiveMods activeMods;
	public static PlayerHead playerHead;
	public static ClickGuiMod clickGuiMod;
	
	
	public void register(HUDManager api) {
		
		modules = new ArrayList<>();
				
		armorStatus = new ArmorStatus();
		api.register(armorStatus);
		modules.add(armorStatus);
		
		clickGuiMod = new ClickGuiMod();
		api.register(armorStatus);
		modules.add(clickGuiMod);
		
		playerHead = new PlayerHead();
		api.register(playerHead);
		modules.add(playerHead);
		
		activeMods = new ActiveMods();
		api.register(activeMods);
		modules.add(activeMods);
		
		FPS = new FPS();
		api.register(FPS);
		modules.add(FPS);
		
		CPS = new CPS();
		api.register(CPS);
		modules.add(CPS);
		
		keystrokes = new Keystrokes();
		api.register(keystrokes);
		modules.add(keystrokes);
		
		coords = new Coordinates();
		api.register(coords);
		modules.add(coords);
		
		targetHud = new TargetHud();
		api.register(targetHud);
		modules.add(targetHud);
		
		freelook = new Freelook();
		api.register(freelook);
		modules.add(freelook);
		
		timeChanger = new TimeChanger();
		//api.register(timeChanger);
		modules.add(timeChanger);
		
		fullbright = new Fullbright();
		//api.register(fullbright);
		modules.add(fullbright);
		
		ping = new Ping();
		api.register(ping);
		modules.add(ping);
		
		potionStatus = new PotionStatus();
		api.register(potionStatus);
		modules.add(potionStatus);
		
		toggleSprint = new ToggleSprint();
		api.register(toggleSprint);
		modules.add(toggleSprint);
		
		smallSword = new SmallSword();
		//api.register(smallSword);
		modules.add(smallSword);
		
		blockOverlay = new BlockOverlay();
		//api.register(blockOverlay);
		modules.add(blockOverlay);
		
		/*notifications = new Notifications();
		api.register(notifications);
		modules.add(notifications);*/

		clock = new Clock();
		api.register(clock);
		modules.add(clock);
		
		betterScoreboard = new BetterScoreboard();
		//api.register(betterScoreboard);
		modules.add(betterScoreboard);
		
		swordAnimations = new SwordAnimations();
		//api.register(swordAnimations);
		modules.add(swordAnimations);
		
		watermark = new Watermark();
		api.register(watermark);
		modules.add(watermark);
		
		/*for(Addon addon : AddonManager.addons) {
			api.register(addon);
		}*/
	}

	public static Freelook getFreelook() {
		return freelook;
	}
	
	public static TimeChanger getModTimeChanger() {
		return timeChanger;
	}   
	
	public static ToggleSprint getToggleSprint() {
		return toggleSprint;
	}

	public static ArrayList<ModDraggable> getModules() {
		return modules;
	}
	
	public static ArrayList<ModDraggable> getModsByCategory(Category c){
		ArrayList<ModDraggable> list = (ArrayList<ModDraggable>) getModules().stream().filter(m -> m.getCategory().equals(c)).collect(Collectors.toList());
		return list;
	}
	
	
}
