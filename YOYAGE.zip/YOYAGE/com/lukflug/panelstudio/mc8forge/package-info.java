/**
 * PanelStudio-MC utility functions designed for Minecraft Forge 1.8.9.
 * This library was built using ForgeGradle, does however not use any Forge APIs in the code itself.
 * May work on MCP projects without forge or other Minecraft releases.
 * However, this has not been tested.
 * @author lukflug
 */
package com.lukflug.panelstudio.mc8forge;
