/**
 * Implements interfaces to module settings and corresponding GUI components.
 * @author lukflug
 */
package com.lukflug.panelstudio.settings;
