/**
 * This package and its sub-packages contain all of PanelStudio.
 * The root package contains core PanelStudio classes.
 * @author lukflug
 */
package com.lukflug.panelstudio;
