/**
 * This package implements the TabGUI.
 * @author lukflug
 */
package com.lukflug.panelstudio.tabgui;
