package glori.tech.glorigui.util;

public interface Toggler {
	
	
	
	public boolean isToggled();

	public void setToggled(boolean toggled);
	
	public void toggle();
	
	public String getName();

}
