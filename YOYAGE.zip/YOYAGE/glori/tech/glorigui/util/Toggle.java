package glori.tech.glorigui.util;

public class Toggle {
	
	public boolean toggled;
	public String name;
	
	public boolean isToggled() {
		return toggled;
	}

	public void setToggled(boolean toggled) {
		this.toggled = toggled;
	}
	
	public void toggle() {
		toggled = !toggled;
	}
	
	public String getName() {
		return name;
	}

}
