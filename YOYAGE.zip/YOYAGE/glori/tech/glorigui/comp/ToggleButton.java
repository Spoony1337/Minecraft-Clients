package glori.tech.glorigui.comp;

import java.awt.Color;

import dev.voyageclient.gui.clickgui.newgui.setting.SettingGUI;
import glori.tech.glorigui.Panel;
import glori.tech.glorigui.util.GloriDraw;
import glori.tech.glorigui.util.Toggler;
import net.minecraft.client.Minecraft;

public class ToggleButton {
	
	protected final int x, y;
	protected int  w, h;
	protected final Toggler toggle;
	protected final Panel parent;
	protected final String text;
	
	public ToggleButton(String text, int x, int y, int w, int h, Toggler toggle, Panel parent) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.toggle = toggle;
		this.parent = parent;
		this.text = text;
	}
	
	public void draw() {
		GloriDraw.drawBorderedRoundedRect(x, y, w, h, 10, getColor(), new Color(0, 0, 0, 255).getRGB());
		Minecraft.getMinecraft().fontRendererObj.drawString(text, x + 2, y - h, -1);
	}
	
	private int getColor() {
		if(toggle.isToggled()) {
			return new Color(0, 255, 0, 255).getRGB();
		} else {
			return new Color(255, 0, 0, 255).getRGB();
		}
	}
	
	public void onClick(int mouseX, int mouseY, int button) {
		if(mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= y + h) {
			toggle.toggle();
		}
	}

}
