package glori.tech.glorigui;

import java.io.IOException;
import java.util.ArrayList;

import dev.voyageclient.gui.clickgui.newgui.component.ModComponent;
import glori.tech.glorigui.comp.ToggleButton;
import glori.tech.glorigui.util.GloriDraw;
import net.minecraft.client.gui.GuiScreen;

public class Panel {
	
	protected final int x, y, w, h, color;
	protected final ArrayList<ToggleButton> toggleButtons;
	public GloriGUI parent;
	
	public Panel(int x, int y, int w, int h, int color, GloriGUI parent) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.color = color;
		this.parent = parent;
		toggleButtons = new ArrayList<ToggleButton>();
	}
	
	public void addButton(ToggleButton button) {
		toggleButtons.add(button);
	}
	
	public void drawPanel() {
		GloriDraw.drawRoundedRect(x, y, w, h, 10, color);
		for(ToggleButton toggleButton : toggleButtons) {
			toggleButton.draw();
		}
	}
	
	public void mouseClicked(int mouseX, int mouseY, int button) throws IOException{
		for(ToggleButton toggleButton : toggleButtons) {
			toggleButton.onClick(mouseX, mouseY, button);
		}
	}

}
