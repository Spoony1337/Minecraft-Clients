package glori.tech.glorigui;

import java.io.IOException;
import java.util.ArrayList;

import glori.tech.glorigui.comp.ToggleButton;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;

public class GloriGUI extends GuiScreen {
	
	protected final ArrayList<Panel> panels = new ArrayList<Panel>();
	
	@Override
	public void drawScreen(int mouseX, int mouseY, float partialTicks) {
		super.drawScreen(mouseX, mouseY, partialTicks);
		this.renderGUI();
	}
	
	private void renderGUI() {
		for(Panel panel : panels) {
			panel.drawPanel();
		}
	}
	
	public void activate() {
		Minecraft.getMinecraft().displayGuiScreen(this);

	}
	
	public void drawString(String string, int x, int y, int color) {
		Minecraft.getMinecraft().fontRendererObj.drawString(string, x, y, color);
	}
	
	@Override
	public void mouseClicked(int mouseX, int mouseY, int button) throws IOException{
		for(Panel panel : panels) {
			panel.mouseClicked(mouseX, mouseY, button);
		}
	}
}
