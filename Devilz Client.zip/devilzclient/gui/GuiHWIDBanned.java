package devilzclient.gui;

import devilzclient.util.*;
import net.minecraft.event.*;
import devilzclient.http.*;
import net.minecraft.util.*;
import javax.sound.sampled.*;
import org.lwjgl.opengl.*;
import net.minecraft.client.gui.*;
import java.io.*;

public class GuiHWIDBanned extends GuiScreen
{
    private AnimatedResourceLocation gif;
    static Clip clip;
    private IChatComponent[] message;
    private int messageLengthTimesFontHeight;
    
    public GuiHWIDBanned(final String reason) {
        this.gif = new AnimatedResourceLocation("devilzclient/ban", 44, 1);
        this.message = new IChatComponent[] { new ChatComponentText(new StringBuilder().append(EnumChatFormatting.GOLD).append(EnumChatFormatting.BOLD).append("You have been HWID banned from Devilz Client!").toString()), new ChatComponentText(""), new ChatComponentText("You have been banned for: "), new ChatComponentText(""), new ChatComponentText(EnumChatFormatting.AQUA + reason), new ChatComponentText(""), new ChatComponentText("You can appeal your ban at " + EnumChatFormatting.YELLOW + "http://client.devilzesports.lk").setChatStyle(new ChatStyle().setChatClickEvent(new ClickEvent(ClickEvent.Action.OPEN_URL, "http://client.devilzesports.lk")).setChatHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new ChatComponentText("Click to open link").setChatStyle(new ChatStyle().setColor(EnumChatFormatting.GREEN))))), new ChatComponentText(""), new ChatComponentText("Your HWID is: " + EnumChatFormatting.RED + HWID.get()).setChatStyle(new ChatStyle().setChatHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new ChatComponentText("Click to copy your HWID").setChatStyle(new ChatStyle().setColor(EnumChatFormatting.GREEN)))).setChatClickEvent(new ClickEvent(ClickEvent.Action.COPY_CLIPBOARD, HWID.get()))), new ChatComponentText("") };
    }
    
    @Override
    public void initGui() {
        super.initGui();
        this.buttonList.add(new GuiButton(0, this.width / 2 - 100, this.height - 30, "Guess i'll just go outside"));
        this.gif = new AnimatedResourceLocation("clientname/ban", 44, 1);
        if (GuiHWIDBanned.clip == null) {
            try {
                final InputStream in = this.mc.mcDefaultResourcePack.getInputStream(new ResourceLocation("clientname/ban/music.wav"));
                (GuiHWIDBanned.clip = AudioSystem.getClip()).open(AudioSystem.getAudioInputStream(in));
                GuiHWIDBanned.clip.start();
            }
            catch (Exception ex) {}
        }
        this.messageLengthTimesFontHeight = this.message.length * this.fontRendererObj.FONT_HEIGHT;
    }
    
    @Override
    public void drawScreen(final int mouseX, final int mouseY, final float partialTicks) {
        this.drawGradientRect(0, 0, this.width, this.height, -12574688, -11530224);
        this.gif.update();
        this.mc.getTextureManager().bindTexture(this.gif.getTexture());
        GL11.glPushMatrix();
        GL11.glTranslated((double)(this.width / 2 - 98), (double)(this.height / 2 - 60), 0.0);
        GL11.glScaled(0.4, 0.4, 0.0);
        Gui.drawModalRectWithCustomSizedTexture(0, 0, 0.0f, 0.0f, 498, 494, 498.0f, 494.0f);
        GL11.glPopMatrix();
        int i = 50 - this.messageLengthTimesFontHeight / 2;
        IChatComponent[] message;
        for (int length = (message = this.message).length, j = 0; j < length; ++j) {
            final IChatComponent s = message[j];
            this.drawCenteredString(this.fontRendererObj, s.getFormattedText(), (float)(this.width / 2), (float)i, 16777215);
            i += this.fontRendererObj.FONT_HEIGHT;
        }
        this.handleComponentHover(this.findChatComponent(mouseX, mouseY), mouseX, mouseY);
        super.drawScreen(mouseX, mouseY, partialTicks);
    }
    
    private IChatComponent findChatComponentLine(final int mouseY) {
        int i = 50 - this.messageLengthTimesFontHeight / 2;
        IChatComponent[] message;
        for (int length = (message = this.message).length, j = 0; j < length; ++j) {
            final IChatComponent s = message[j];
            final int yTop = i;
            final int yBottom = i + this.fontRendererObj.FONT_HEIGHT;
            if (mouseY >= yTop && mouseY < yBottom) {
                return s;
            }
            i += this.fontRendererObj.FONT_HEIGHT;
        }
        return null;
    }
    
    private IChatComponent findChatComponent(final int mouseX, final int mouseY) {
        final IChatComponent s = this.findChatComponentLine(mouseY);
        if (s == null || !(s instanceof ChatComponentText)) {
            return null;
        }
        final int stringWidth = this.mc.fontRendererObj.getStringWidth(GuiUtilRenderComponents.func_178909_a(((ChatComponentText)s).getChatComponentText_TextValue(), false));
        final int xLeft = this.width / 2 - stringWidth / 2;
        final int xRight = this.width / 2 + stringWidth / 2;
        if (mouseX >= xLeft && mouseX < xRight) {
            return s;
        }
        return null;
    }
    
    @Override
    protected void mouseClicked(final int mouseX, final int mouseY, final int mouseButton) throws IOException {
        if (mouseButton == 0) {
            final IChatComponent ichatcomponent = this.findChatComponent(mouseX, mouseY);
            if (this.handleComponentClick(ichatcomponent)) {
                return;
            }
        }
        super.mouseClicked(mouseX, mouseY, mouseButton);
    }
    
    @Override
    protected void keyTyped(final char typedChar, final int keyCode) throws IOException {
        super.keyTyped(typedChar, keyCode);
    }
    
    @Override
    protected void actionPerformed(final GuiButton button) throws IOException {
        this.mc.shutdown();
    }
    
    @Override
    public void onGuiClosed() {
        try {
            GuiHWIDBanned.clip.close();
        }
        catch (Exception ex) {}
        super.onGuiClosed();
    }
}
