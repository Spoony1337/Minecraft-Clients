package devilzclient.gui.hud;

public interface IRenderConfig
{
    void save(final ScreenPosition p0);
    
    ScreenPosition load();
}
