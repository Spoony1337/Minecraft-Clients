package devilzclient.gui;

import net.minecraft.client.gui.*;
import net.minecraft.client.resources.*;
import java.io.*;
import java.net.*;
import com.mojang.authlib.yggdrasil.*;
import com.mojang.authlib.*;
import net.minecraft.util.*;
import java.awt.*;

public class GuiAltLogin extends GuiScreen
{
    private GuiScreen parent;
    private String status;
    private GuiTextField loginField;
    
    public GuiAltLogin(final GuiScreen guiMainMenu) {
        this.parent = guiMainMenu;
    }
    
    @Override
    public void initGui() {
        this.status = "\ufffd7Waiting..";
        final int width = 100;
        final int height = 20;
        final int offset = 2;
        this.buttonList.add(new GuiButton(0, this.width / 2 - width / 2, this.height - height - offset, width, height, "Login"));
        this.buttonList.add(new GuiButton(1, this.width / 2 - width / 2, this.height - (height + offset) * 2, width, height, I18n.format("gui.back", new Object[0])));
        (this.loginField = new GuiTextField(2, this.fontRendererObj, this.width / 2 - 100, this.height / 4, 200, 20)).setFocused(true);
        this.loginField.setText("");
    }
    
    @Override
    protected void keyTyped(final char typedChar, final int keyCode) throws IOException {
        this.loginField.textboxKeyTyped(typedChar, keyCode);
        if (keyCode == 1) {
            this.actionPerformed(this.buttonList.get(1));
        }
        if (keyCode == 28) {
            this.actionPerformed(this.buttonList.get(0));
        }
    }
    
    @Override
    protected void actionPerformed(final GuiButton button) throws IOException {
        if (button.id == 0) {
            if (this.loginField.getText() != null && !this.loginField.getText().isEmpty()) {
                if (!this.loginField.getText().contains(" ")) {
                    try {
                        final String[] args = this.loginField.getText().split(":");
                        if (args[0].contains("@")) {
                            final YggdrasilUserAuthentication authentication = (YggdrasilUserAuthentication)new YggdrasilAuthenticationService(Proxy.NO_PROXY, "").createUserAuthentication(Agent.MINECRAFT);
                            authentication.setUsername(args[0]);
                            authentication.setPassword(args[1]);
                            try {
                                authentication.logIn();
                                this.mc.session = new Session(authentication.getSelectedProfile().getName(), authentication.getSelectedProfile().getId().toString(), authentication.getAuthenticatedToken(), "mojang");
                                System.out.println(this.status = "Logged in successfully as " + this.mc.session.getUsername());
                            }
                            catch (Exception e) {
                                System.out.println(this.status = "ERROR: ALT HAS INVALID INTTIALIS");
                            }
                        }
                        else {
                            System.out.println(this.status = "ERROR: ALT IS NOT PREMIUM");
                        }
                    }
                    catch (Exception e2) {
                        System.out.println(this.status = "ERROR: INVALID TO ALT");
                    }
                }
                else {
                    System.out.println(this.status = "ERROR: INVALID TO ALT");
                }
            }
            else {
                System.out.println(this.status = "ERROR: NO ALT IN FIELD");
            }
        }
        else if (button.id == 1) {
            this.mc.displayGuiScreen(this.parent);
        }
    }
    
    @Override
    public void drawScreen(final int mouseX, final int mouseY, final float partialTicks) {
        this.drawDefaultBackground();
        this.drawCenteredString(this.fontRendererObj, "ALT Login", (float)(this.width / 2), 10.0f, Color.WHITE.getRGB());
        this.drawCenteredString(this.fontRendererObj, "format: email:password", (float)(this.width / 2), 20.0f, Color.WHITE.getRGB());
        this.drawCenteredString(this.fontRendererObj, "not all alts work!", (float)(this.width / 2), 30.0f, Color.WHITE.getRGB());
        this.drawCenteredString(this.fontRendererObj, this.status, (float)(this.width / 2), 40.0f, Color.WHITE.getRGB());
        this.loginField.drawTextBox();
        super.drawScreen(mouseX, mouseY, partialTicks);
    }
    
    @Override
    public void updateScreen() {
        this.loginField.updateCursorCounter();
    }
}
