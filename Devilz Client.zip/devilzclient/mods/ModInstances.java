package devilzclient.mods;

import devilzclient.mods.impl.*;
import devilzclient.gui.hud.*;

public class ModInstances
{
    private static ModArmorStatus modArmorStatus;
    private static ModFPS modFPS;
    private static ModXYZ modXYZ;
    private static ModKeystrokes modKeystrokes;
    private static ModCPS modCPS;
    private static ClockMod clockMod;
    private static ModPing modPing;
    private static ModTimeChanger modTimeChanger;
    private static ModFullbright modFullbright;
    private static ModHealthIndicator modHealthIndicator;
    private static ModPotionStatus modPotionStatus;
    private static ModCoords modCoords;
    private static ModMLGHelper modMLGHelper;
    
    public static void register(final HUDManager api) {
        ModInstances.modArmorStatus = new ModArmorStatus();
        api.register(ModInstances.modArmorStatus);
        ModInstances.modFPS = new ModFPS();
        api.register(ModInstances.modFPS);
        ModInstances.modXYZ = new ModXYZ();
        api.register(ModInstances.modXYZ);
        ModInstances.modKeystrokes = new ModKeystrokes();
        api.register(ModInstances.modKeystrokes);
        ModInstances.modCPS = new ModCPS();
        api.register(ModInstances.modCPS);
        ModInstances.clockMod = new ClockMod();
        api.register(ModInstances.clockMod);
        ModInstances.modPing = new ModPing();
        api.register(ModInstances.modPing);
        ModInstances.modTimeChanger = new ModTimeChanger();
        api.register(ModInstances.modTimeChanger);
        ModInstances.modFullbright = new ModFullbright();
        api.register(ModInstances.modFullbright);
        ModInstances.modHealthIndicator = new ModHealthIndicator();
        api.register(ModInstances.modHealthIndicator);
        ModInstances.modPotionStatus = new ModPotionStatus();
        api.register(ModInstances.modPotionStatus);
        ModInstances.modCoords = new ModCoords();
        api.register(ModInstances.modCoords);
        ModInstances.modMLGHelper = new ModMLGHelper();
        api.register(ModInstances.modMLGHelper);
    }
    
    public static ModTimeChanger getModTimeChanger() {
        return ModInstances.modTimeChanger;
    }
}
