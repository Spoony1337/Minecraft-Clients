package devilzclient.mods.impl;

import devilzclient.mods.*;
import devilzclient.gui.hud.*;

public class ModTimeChanger extends ModDraggable
{
    private ScreenPosition pos;
    
    @Override
    public int getWidth() {
        return 0;
    }
    
    @Override
    public int getHeight() {
        return 0;
    }
    
    @Override
    public void render(final ScreenPosition pos) {
    }
}
