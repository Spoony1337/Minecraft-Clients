package devilzclient.mods.impl;

import devilzclient.mods.*;
import devilzclient.gui.hud.*;
import net.minecraft.entity.*;

public class ModHealthIndicator extends ModDraggable
{
    private ScreenPosition pos;
    
    @Override
    public int getWidth() {
        return this.font.getStringWidth("HP: 20");
    }
    
    @Override
    public int getHeight() {
        return this.font.FONT_HEIGHT;
    }
    
    @Override
    public void render(final ScreenPosition pos) {
        if (this.mc.pointedEntity != null && this.mc.pointedEntity instanceof EntityLiving) {
            final EntityLiving entityRaytraced = (EntityLiving)this.mc.pointedEntity;
            this.font.drawString("HP: " + (int)entityRaytraced.getHealth(), pos.getAbsoluteX() + 1, pos.getAbsoluteY() + 1, -1);
        }
    }
    
    @Override
    public void renderDummy(final ScreenPosition pos) {
        this.font.drawString("HP: 20", pos.getAbsoluteX() + 1, pos.getAbsoluteY() + 1, -16711936);
    }
    
    @Override
    public void save(final ScreenPosition pos) {
        this.pos = pos;
    }
    
    @Override
    public ScreenPosition load() {
        return this.pos;
    }
}
