package devilzclient.mods.impl;

import devilzclient.mods.*;
import net.minecraft.client.*;
import devilzclient.gui.hud.*;
import net.minecraft.client.gui.*;
import net.minecraft.util.*;
import net.minecraft.world.chunk.*;

public class ModCoords extends ModDraggable
{
    private String biomeName;
    private int subwidth;
    private int truewidth;
    
    @Override
    public int getWidth() {
        final int xwidth = this.font.getStringWidth("X: " + Math.round(Minecraft.getMinecraft().thePlayer.posX * 1000.0) / 1000L);
        final int Ywidth = this.font.getStringWidth("Y: " + Math.round(Minecraft.getMinecraft().thePlayer.posY * 1000.0) / 1000L);
        final int Zwidth = this.font.getStringWidth("Z: " + Math.round(Minecraft.getMinecraft().thePlayer.posZ * 1000.0) / 1000L);
        final int BiomeWidth = this.font.getStringWidth("Biome: " + this.biomeName);
        if (xwidth > Ywidth && xwidth > Zwidth) {
            this.subwidth = xwidth;
        }
        else if (Ywidth > xwidth && Ywidth > Zwidth) {
            this.subwidth = Ywidth;
        }
        else {
            this.subwidth = Zwidth;
        }
        if (BiomeWidth > this.subwidth) {
            this.truewidth = BiomeWidth;
        }
        else {
            this.truewidth = this.subwidth;
        }
        if (this.truewidth < 90) {
            this.truewidth = 90;
        }
        return this.truewidth + 6;
    }
    
    @Override
    public int getHeight() {
        return 45;
    }
    
    @Override
    public void render(final ScreenPosition pos) {
        Gui.drawRect(pos.getAbsoluteX(), pos.getAbsoluteY(), pos.getAbsoluteX() + this.getWidth() + 1, pos.getAbsoluteY() + this.getHeight(), -1879048192);
        this.font.drawStringWithShadow("X: " + Math.round(Minecraft.getMinecraft().thePlayer.posX * 1000.0) / 1000L, (float)(pos.getAbsoluteX() + 3), (float)(pos.getAbsoluteY() + 4), -1);
        this.font.drawStringWithShadow("Y: " + Math.round(Minecraft.getMinecraft().thePlayer.posY * 1000.0) / 1000L, (float)(pos.getAbsoluteX() + 3), (float)(pos.getAbsoluteY() + 10 + 4), -1);
        this.font.drawStringWithShadow("Z: " + Math.round(Minecraft.getMinecraft().thePlayer.posZ * 1000.0) / 1000L, (float)(pos.getAbsoluteX() + 3), (float)(pos.getAbsoluteY() + 20 + 4), -1);
        final BlockPos blockpos = new BlockPos(this.mc.getRenderViewEntity().posX, this.mc.getRenderViewEntity().getEntityBoundingBox().minY, this.mc.getRenderViewEntity().posZ);
        if (this.mc.theWorld != null && this.mc.theWorld.isBlockLoaded(blockpos)) {
            final Chunk chunk = this.mc.theWorld.getChunkFromBlockCoords(blockpos);
            this.biomeName = chunk.getBiome(blockpos, this.mc.theWorld.getWorldChunkManager()).biomeName;
            this.font.drawStringWithShadow("Biome: " + this.biomeName, (float)(pos.getAbsoluteX() + 3), (float)(pos.getAbsoluteY() + 30 + 4), -1);
        }
    }
}
