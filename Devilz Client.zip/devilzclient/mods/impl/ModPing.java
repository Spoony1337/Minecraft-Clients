package devilzclient.mods.impl;

import devilzclient.mods.*;
import net.minecraft.client.*;
import devilzclient.gui.hud.*;

public class ModPing extends ModDraggable
{
    @Override
    public int getWidth() {
        return this.font.getStringWidth("Ping: " + Minecraft.getMinecraft().getNetHandler().getPlayerInfo(Minecraft.getMinecraft().thePlayer.getUniqueID()).getResponseTime());
    }
    
    @Override
    public int getHeight() {
        return this.font.FONT_HEIGHT;
    }
    
    @Override
    public void render(final ScreenPosition pos) {
        this.font.drawStringWithShadow(String.valueOf(Minecraft.getMinecraft().getNetHandler().getPlayerInfo(Minecraft.getMinecraft().thePlayer.getUniqueID()).getResponseTime()) + " ms", (float)(pos.getAbsoluteX() + 1), (float)(pos.getAbsoluteY() + 1), -1);
    }
}
