package devilzclient.mods.impl;

import devilzclient.mods.*;
import devilzclient.gui.hud.*;
import net.minecraft.client.*;

public class ModFullbright extends ModDraggable
{
    private ScreenPosition pos;
    
    public ModFullbright() {
        Minecraft.getMinecraft().gameSettings.gammaSetting = 10.0f;
    }
    
    @Override
    public int getWidth() {
        return 0;
    }
    
    @Override
    public int getHeight() {
        return 0;
    }
    
    @Override
    public void render(final ScreenPosition pos) {
    }
    
    @Override
    public void save(final ScreenPosition pos) {
    }
    
    @Override
    public ScreenPosition load() {
        return this.pos;
    }
}
