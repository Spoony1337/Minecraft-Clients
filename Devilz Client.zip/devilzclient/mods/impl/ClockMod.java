package devilzclient.mods.impl;

import devilzclient.mods.*;
import devilzclient.gui.hud.*;
import java.time.format.*;
import java.time.*;
import java.time.temporal.*;

public class ClockMod extends ModDraggable
{
    @Override
    public int getWidth() {
        return this.font.getStringWidth(this.getTime());
    }
    
    @Override
    public int getHeight() {
        return this.font.FONT_HEIGHT;
    }
    
    @Override
    public void render(final ScreenPosition pos) {
        this.font.drawString(this.getTime(), pos.getAbsoluteX() + 1, pos.getAbsoluteY() + 1, -1);
    }
    
    private String getTime() {
        final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("h:mm a");
        final LocalDateTime localtime = LocalDateTime.now();
        return dtf.format(localtime);
    }
}
