package devilzclient.mods;

import net.minecraft.client.*;
import net.minecraft.client.gui.*;
import devilzclient.*;
import devilzclient.event.*;

public abstract class Mod
{
    private boolean isEnabled;
    protected final Minecraft mc;
    protected final FontRenderer font;
    protected final Client client;
    
    public Mod() {
        this.isEnabled = true;
        this.mc = Minecraft.getMinecraft();
        this.font = this.mc.fontRendererObj;
        this.client = Client.getInstance();
        this.setEnabled(this.isEnabled);
    }
    
    public void setEnabled(final boolean isEnabled) {
        this.isEnabled = isEnabled;
        if (isEnabled) {
            EventManager.register(this);
        }
        else {
            EventManager.unregister(this);
        }
    }
    
    public boolean isEnabled() {
        return this.isEnabled;
    }
}
