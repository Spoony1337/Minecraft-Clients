package devilzclient.http;

import com.google.gson.*;
import net.minecraft.client.*;
import org.apache.http.*;
import org.apache.http.message.*;
import java.util.*;
import devilzclient.http.gsonobjs.*;

public class HTTPFunctions
{
    private static final Gson gson;
    
    static {
        gson = new Gson();
    }
    
    public static void sendHWIDMap() {
        final Minecraft mc = Minecraft.getMinecraft();
        final List<NameValuePair> params = new ArrayList<NameValuePair>();
        params.add((NameValuePair)new BasicNameValuePair("uuid", mc.getSession().getProfile().getId().toString()));
        params.add((NameValuePair)new BasicNameValuePair("username", mc.getSession().getProfile().getName()));
        params.add((NameValuePair)new BasicNameValuePair("hwid", HWID.get()));
        HTTPUtils.sendPostAsync("http://client.devilzesports.lk:8080/api/mapUUID/", params);
    }
    
    public static boolean isAPIUp() {
        final HTTPReply reply = HTTPUtils.sendGet("http://client.devilzesports.lk:8080/api/");
        return reply.getStatusCode() == 200;
    }
    
    public static boolean isBanned() {
        final List<NameValuePair> params = new ArrayList<NameValuePair>();
        params.add((NameValuePair)new BasicNameValuePair("hwid", HWID.get()));
        final HTTPReply reply = HTTPUtils.sendGet("http://client.devilzesports.lk:8080/api/isBanned/", params);
        if (reply.getStatusCode() == 200) {
            final ObjIsBanned obj = (ObjIsBanned)HTTPFunctions.gson.fromJson(reply.getBody(), (Class)ObjIsBanned.class);
            return obj.isBanned();
        }
        return false;
    }
    
    public static boolean isWhitelisted() {
        final List<NameValuePair> params = new ArrayList<NameValuePair>();
        params.add((NameValuePair)new BasicNameValuePair("hwid", HWID.get()));
        final HTTPReply reply = HTTPUtils.sendGet("http://client.devilzesports.lk:8080/api/isWhitelisted/", params);
        if (reply.getStatusCode() == 200) {
            final ObjIsWhitelisted obj = (ObjIsWhitelisted)HTTPFunctions.gson.fromJson(reply.getBody(), (Class)ObjIsWhitelisted.class);
            return obj.isWhitelisted();
        }
        return false;
    }
    
    public static ObjUserCosmetics[] downloadUserCosmetics() {
        return (ObjUserCosmetics[])HTTPFunctions.gson.fromJson(HTTPUtils.sendGet("http://client.devilzesports.lk:8080/api/cosmetics/").getBody(), (Class)ObjUserCosmetics[].class);
    }
    
    public static ObjGlobalSettings downloadGlobalSettings() {
        return (ObjGlobalSettings)HTTPFunctions.gson.fromJson(HTTPUtils.sendGet("http://client.devilzesports.lk:8080/api/globalSettings/").getBody(), (Class)ObjGlobalSettings.class);
    }
}
