package devilzclient.http.gsonobjs;

public class ObjGlobalSettings
{
    private boolean isWhitelisted;
    private String latestVersion;
    
    public String getLatestVersion() {
        return this.latestVersion;
    }
    
    public boolean isWhitelisted() {
        return this.isWhitelisted;
    }
}
