package devilzclient.http.gsonobjs;

public class ObjIsBanned
{
    private String hwid;
    private int isBanned;
    
    public String getHwid() {
        return this.hwid;
    }
    
    public boolean isBanned() {
        return this.isBanned == 1;
    }
}
