package devilzclient.http.gsonobjs;

import java.util.*;

public class ObjUserCosmetics
{
    private String uuid;
    private String cape_style;
    private int googly_eyes;
    private Hat hat;
    
    public Hat getHat() {
        return this.hat;
    }
    
    public UUID getUuid() {
        return UUID.fromString(this.uuid);
    }
    
    public boolean isGooglyEyesEnabled() {
        return this.googly_eyes == 1;
    }
    
    public boolean hasCape() {
        return this.cape_style != null;
    }
    
    public String getCapeStyle() {
        return this.cape_style;
    }
    
    public class Hat
    {
        private int enabled;
        private int r;
        private int g;
        private int b;
        
        public boolean isEnabled() {
            return this.enabled == 1;
        }
        
        public float[] getColor() {
            return new float[] { this.convert(this.r), this.convert(this.g), this.convert(this.b) };
        }
        
        private float convert(final int color) {
            return color / 255.0f;
        }
    }
}
