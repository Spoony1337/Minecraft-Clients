package devilzclient.http.gsonobjs;

public class ObjIsWhitelisted
{
    private String hwid;
    private int isWhitelisted;
    
    public String getHwid() {
        return this.hwid;
    }
    
    public boolean isWhitelisted() {
        return this.isWhitelisted == 1;
    }
}
