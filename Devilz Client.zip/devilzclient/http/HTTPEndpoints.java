package devilzclient.http;

public class HTTPEndpoints
{
    public static final String BASE = "http://client.devilzesports.lk:8080/api/";
    public static final String MAP_UUID = "http://client.devilzesports.lk:8080/api/mapUUID/";
    public static final String IS_BANNED = "http://client.devilzesports.lk:8080/api/isBanned/";
    public static final String IS_WHITELISTED = "http://client.devilzesports.lk:8080/api/isWhitelisted/";
    public static final String GLOBAL_SETTINGS = "http://client.devilzesports.lk:8080/api/globalSettings/";
    public static final String COSMETICS = "http://client.devilzesports.lk:8080/api/cosmetics/";
    public static final String STATIC = "http://client.devilzesports.lk:8080/api/static/client/";
}
