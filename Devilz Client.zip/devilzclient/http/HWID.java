package devilzclient.http;

public class HWID
{
    public static String get() {
        return "fake-hwid";
    }
}
