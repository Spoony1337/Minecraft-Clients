package devilzclient.http;

import org.apache.http.*;
import org.apache.http.util.*;

public class HTTPReply
{
    private String body;
    private int statusCode;
    
    public HTTPReply(final HttpResponse resp) {
        if (resp == null) {
            this.body = "";
            this.statusCode = -1;
        }
        else {
            this.statusCode = resp.getStatusLine().getStatusCode();
            try {
                this.body = EntityUtils.toString(resp.getEntity());
            }
            catch (Exception e) {
                this.body = "error";
            }
        }
    }
    
    public String getBody() {
        return this.body;
    }
    
    public int getStatusCode() {
        return this.statusCode;
    }
}
