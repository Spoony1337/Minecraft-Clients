package devilzclient.http;

import java.util.*;
import org.apache.http.client.utils.*;
import org.apache.http.impl.client.*;
import org.apache.http.client.*;
import org.apache.http.client.methods.*;
import org.apache.http.client.entity.*;
import org.apache.http.*;
import java.net.*;
import org.apache.commons.compress.utils.*;
import java.io.*;

public class HTTPUtils
{
    public static HTTPReply sendGet(final String endpoint) {
        return sendGet(endpoint, null);
    }
    
    public static HTTPReply sendGet(String endpoint, final List<NameValuePair> params) {
        try {
            if (params != null) {
                endpoint = String.valueOf(endpoint) + "?" + URLEncodedUtils.format((List)params, "UTF-8");
            }
            final HttpGet httpGet = new HttpGet(endpoint);
            final HttpClient httpClient = (HttpClient)HttpClientBuilder.create().build();
            final HttpResponse httpResponse = httpClient.execute((HttpUriRequest)httpGet);
            return new HTTPReply(httpResponse);
        }
        catch (Exception e) {
            e.printStackTrace();
            return new HTTPReply(null);
        }
    }
    
    public static HTTPReply sendPost(final String endpoint) {
        return sendPost(endpoint, null);
    }
    
    public static HTTPReply sendPost(final String endpoint, final List<NameValuePair> params) {
        try {
            final HttpPost httpPost = new HttpPost(endpoint);
            if (params != null) {
                httpPost.setEntity((HttpEntity)new UrlEncodedFormEntity((List)params));
            }
            final HttpClient httpClient = (HttpClient)HttpClientBuilder.create().build();
            final HttpResponse httpResponse = httpClient.execute((HttpUriRequest)httpPost);
            return new HTTPReply(httpResponse);
        }
        catch (Exception e) {
            e.printStackTrace();
            return new HTTPReply(null);
        }
    }
    
    public static void sendPostAsync(final String endpoint, final List<NameValuePair> params) {
        new Thread() {
            @Override
            public void run() {
                HTTPUtils.sendPost(endpoint, params);
            }
        }.start();
    }
    
    public static boolean downloadFile(final String endpoint, final File path) {
        try {
            final InputStream inputStream = new URL(endpoint).openStream();
            final FileOutputStream fileOutputStream = new FileOutputStream(path);
            IOUtils.copy(inputStream, (OutputStream)fileOutputStream);
            IOUtils.closeQuietly((Closeable)fileOutputStream);
            IOUtils.closeQuietly((Closeable)inputStream);
            return true;
        }
        catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
