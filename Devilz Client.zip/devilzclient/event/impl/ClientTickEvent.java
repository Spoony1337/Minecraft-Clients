package devilzclient.event.impl;

import devilzclient.event.*;

public class ClientTickEvent extends Event
{
}
