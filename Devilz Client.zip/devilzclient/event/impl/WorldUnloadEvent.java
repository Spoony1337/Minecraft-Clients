package devilzclient.event.impl;

import devilzclient.event.*;
import net.minecraft.world.*;

public class WorldUnloadEvent extends Event
{
    private final World world;
    
    public WorldUnloadEvent(final World world) {
        this.world = world;
    }
    
    public World getWorld() {
        return this.world;
    }
}
