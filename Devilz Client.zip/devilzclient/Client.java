package devilzclient;

import devilzclient.gui.hud.*;
import devilzclient.http.gsonobjs.*;
import devilzclient.mods.impl.*;
import devilzclient.http.*;
import devilzclient.cosmetics.*;
import devilzclient.mods.*;
import devilzclient.event.impl.*;
import net.minecraft.client.*;
import devilzclient.gui.options.*;
import net.minecraft.client.gui.*;
import devilzclient.gui.*;
import devilzclient.event.*;

public class Client
{
    private static final Client INSTANCE;
    private DiscordRP discordRP;
    private HUDManager hudManager;
    private volatile boolean isBanned;
    public boolean isWhitelisted;
    private ObjGlobalSettings globalSettings;
    private ModQuickPlay modQuickPlay;
    
    static {
        INSTANCE = new Client();
    }
    
    public Client() {
        this.discordRP = new DiscordRP();
    }
    
    public static final Client getInstance() {
        return Client.INSTANCE;
    }
    
    public void init() {
        FileManager.init();
        SplashProgress.setProgress(0, "Client - Initalising Discord RP!");
        this.discordRP.start();
        EventManager.register(this);
        this.isBanned = HTTPFunctions.isBanned();
        this.isWhitelisted = HTTPFunctions.isWhitelisted();
        this.globalSettings = HTTPFunctions.downloadGlobalSettings();
        CosmeticController.donwloadUserCosmetics();
    }
    
    public void start() {
        ModInstances.register(this.hudManager = HUDManager.getInstance());
        HTTPFunctions.sendHWIDMap();
    }
    
    public void shutdown() {
        this.discordRP.shutdown();
    }
    
    public DiscordRP getDiscordRP() {
        return this.discordRP;
    }
    
    @EventTarget
    public void onTick(final ClientTickEvent e) {
        if (Minecraft.getMinecraft().gameSettings.CLIENT_GUI_MOD_POS.isPressed()) {
            this.hudManager.openConfigScreen();
        }
        if (Minecraft.getMinecraft().gameSettings.MOD_TOGGLE.isPressed()) {
            Minecraft.getMinecraft().displayGuiScreen(new GuiModToggle());
        }
        if (Minecraft.getMinecraft().gameSettings.CLIENT_QUICKPLAY.isPressed()) {
            Minecraft.getMinecraft().displayGuiScreen(new ModQuickPlay(this.modQuickPlay));
        }
        if (this.isBanned && !(Minecraft.getMinecraft().currentScreen instanceof GuiHWIDBanned)) {
            Minecraft.getMinecraft().displayGuiScreen(new GuiHWIDBanned("--reason--"));
        }
        if (this.globalSettings.isWhitelisted() && !this.isWhitelisted && !(Minecraft.getMinecraft().currentScreen instanceof GuiWhitelisted)) {
            Minecraft.getMinecraft().displayGuiScreen(new GuiWhitelisted());
        }
    }
}
