package devilzclient.ui;

import net.minecraft.util.*;
import net.minecraft.client.renderer.*;
import java.awt.*;
import net.minecraft.client.gui.*;
import java.io.*;

public class DevilzMainMenu extends GuiScreen
{
    @Override
    public void drawScreen(final int mouseX, final int mouseY, final float partialTicks) {
        this.mc.getTextureManager().bindTexture(new ResourceLocation("devilzclient/main_menu.png"));
        Gui.drawModalRectWithCustomSizedTexture(0, 0, 0.0f, 0.0f, this.width, this.height, (float)this.width, (float)this.height);
        GlStateManager.pushMatrix();
        GlStateManager.scale(3.0f, 3.0f, 1.0f);
        this.drawCenteredString(this.mc.fontRendererObj, "", 35.0f, (float)(this.height / 2 - 207), -1);
        GlStateManager.popMatrix();
        Gui.drawRect(0, 0, 225, this.height, new Color(0, 0, 0, 170).getRGB());
        super.drawScreen(mouseX, mouseY, partialTicks);
    }
    
    @Override
    public void initGui() {
        this.buttonList.add(new GuiButton(1, 10, this.height / 2 - 40, "Singleplayer"));
        this.buttonList.add(new GuiButton(2, 10, this.height / 2 - 15, "Multiplayer"));
        this.buttonList.add(new GuiButton(3, 10, this.height / 2 + 10, "Options"));
        this.buttonList.add(new GuiButton(4, 10, this.height / 2 + 70, "Exit Game"));
        super.initGui();
    }
    
    @Override
    protected void actionPerformed(final GuiButton button) throws IOException {
        if (button.id == 1) {
            this.mc.displayGuiScreen(new GuiSelectWorld(this));
        }
        if (button.id == 2) {
            this.mc.displayGuiScreen(new GuiMultiplayer(this));
        }
        if (button.id == 3) {
            this.mc.displayGuiScreen(new GuiOptions(this, this.mc.gameSettings));
        }
        if (button.id == 4) {
            this.mc.shutdown();
        }
        super.actionPerformed(button);
    }
}
