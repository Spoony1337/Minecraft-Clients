package devilzclient.cosmetics.impl.eyes;

import net.minecraft.client.entity.*;
import net.minecraft.client.*;
import java.util.*;
import devilzclient.event.*;
import devilzclient.event.impl.*;

public class PhysicsManager
{
    private WeakHashMap<AbstractClientPlayer, EyePhysics> physicsList;
    private static PhysicsManager instance;
    
    static {
        PhysicsManager.instance = null;
    }
    
    public PhysicsManager() {
        this.physicsList = new WeakHashMap<AbstractClientPlayer, EyePhysics>();
    }
    
    public static PhysicsManager getInstance() {
        if (PhysicsManager.instance == null) {
            EventManager.register(PhysicsManager.instance = new PhysicsManager());
        }
        return PhysicsManager.instance;
    }
    
    public EyePhysics getPhysics(final AbstractClientPlayer player) {
        if (!this.physicsList.containsKey(player)) {
            this.physicsList.put(player, new EyePhysics(player));
        }
        return this.physicsList.get(player);
    }
    
    @EventTarget
    public void onTick(final ClientTickEvent event) {
        if (Minecraft.getMinecraft().theWorld != null && !Minecraft.getMinecraft().isGamePaused()) {
            final Iterator<Map.Entry<AbstractClientPlayer, EyePhysics>> iterator = this.physicsList.entrySet().iterator();
            while (iterator.hasNext()) {
                final Map.Entry<AbstractClientPlayer, EyePhysics> e = iterator.next();
                final EyePhysics ep = e.getValue();
                if (ep.getPlayer().worldObj.getWorldTime() - ep.getLastUpdate() > 3L) {
                    iterator.remove();
                }
                else {
                    ep.update();
                }
            }
        }
    }
    
    @EventTarget
    public void onWorldUload(final WorldUnloadEvent event) {
        final Iterator<Map.Entry<AbstractClientPlayer, EyePhysics>> iterator = this.physicsList.entrySet().iterator();
        while (iterator.hasNext()) {
            final Map.Entry<AbstractClientPlayer, EyePhysics> e = iterator.next();
            final EyePhysics ep = e.getValue();
            if (ep.getPlayer().worldObj == event.getWorld()) {
                iterator.remove();
            }
        }
    }
}
